<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CraftAR_model extends CI_Model {

    var $apiKey = "8c50ccb8a93ae6cd2da78e826fe9e08e6151e077";
    var $collectionUUID = "01c36ea606594fa0a276b9695af4cd56";

	public function __construct()
	{
		parent::__construct();
       
        $this->load->library('Management');
	}

	function get_items()
	{

        $response =  $this->management->getItemListByCollection($this->collectionUUID, null, null);
        $collection = $response->getBody();

        $output = array();
        for($i=0; $i < $collection->meta->total_count; $i ++){
            $output[] = $collection->objects[$i];
        }

        return $output;
	}

	function get_images($uuid)
	{

        $response =  $this->management->getImageListByItem($uuid, null, null);
        $collection = $response->getBody();

        $output = array();
        for($i=0; $i < $collection->meta->total_count; $i ++){
            $output[] = $collection->objects[$i];
        }

        return $output;
	}

	
	function count_all_images($uuid)
	{
		$response =  $this->management->getImageListByItem($uuid, null, null);
        $collection = $response->getBody();

        return $collection->meta->total_count;
	}

	public function count_all()
	{
        $response =  $this->management->getItemListByCollection($this->collectionUUID, null, null);
        $collection = $response->getBody();

        return $collection->meta->total_count;

	}

	public function get_by_id($id)
	{

	}

	public function save($data)
	{
		$this->db->insert('building_info', $data);
				
		return $this->db->insert_id();
	}

	public function save_image($data){
		//error_log('CCCCCC'.json_encode($data));
		$response = $this->management->createImage($data['uuid'], $data['tmp_img']);
		$image = $response->getBody();
		sleep(5);

	}
	
	public function get_item($uuid){
		$this->db->from('building_info');
		$this->db->where('uuid',$uuid);
		$query = $this->db->get();

		$output = $query->row();
		
		

		//error_log('CCCCCCCCCCCCC'.json_encode($output));

      
		
        return $output;
	}
	
	public function update($where, $data)
	{
		$this->db->update('building_info', $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('uuid', $id);
		$this->db->delete('building_info');
        $response =  $this->management->deleteItem($id);
		

	}

}
