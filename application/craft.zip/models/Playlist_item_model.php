<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Playlist_item_model extends CI_Model {

	var $table = 'playlist_item';
	var $column_order = array(null,'name','primary_asset','secondary_asset','tertiary_asset','template_name',null); //set column field database for datatable orderable
	var $column_search = array('a.name'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('a.order_id' => 'asc'); // default order 

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	private function _get_main_clause_query(){
		$this->db->select('a.playlist_item_id, 
			a.playlist_id,
			a.name, 
			b.download_path as primary_asset, 
			b.file_type as primary_file_type, 
			c.download_path as secondary_asset, 
			c.file_type as secondary_file_type, 
			d.download_path as tertiary_asset, 
			d.file_type as tertiary_file_type, 
			e.description as template_name,
			a.template_id,
			a.created_by,
			a.log_date_created,
			f.first_name,
			f.last_name,
			a.active');
		$this->db->from('playlist_item a');
		$this->db->join('assets b', 'a.primary_asset_id = b.assets_id', 'left');
		$this->db->join('assets c', 'a.secondary_asset_id = c.assets_id', 'left');
		$this->db->join('assets d', 'a.tertiary_asset_id = d.assets_id', 'left');
		$this->db->join('look_up e', 'a.template_id = e.look_up_id', 'left');
		$this->db->join('participant f', 'a.created_by = f.participant_id', 'left');
		
	}

	private function _get_datatables_query()
	{
		$this->_get_main_clause_query();

		$i = 0;
	
		foreach ($this->column_search as $item) // loop column 
		{
			if($_POST['search']['value']) // if datatable send POST for search
			{
				
				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $_POST['search']['value']);
				}
				else
				{
					$this->db->or_like($item, $_POST['search']['value']);
				}

				if(count($this->column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables($parent_id)
	{
		$this->_get_datatables_query();
		$this->db->where('a.playlist_id', $parent_id);

		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		
		return $query->result();
	}
	
	function count_filtered($parent_id)
	{
		$this->_get_datatables_query();
		$this->db->where('a.playlist_id', $parent_id);
		
		$query = $this->db->get();
		return $query->num_rows();
	}

	function count_all_by_parent($parent_id)
	{
		$this->_get_main_clause_query($parent_id);
		$this->db->where('a.playlist_id', $parent_id);
		$query = $this->db->get();
		return $query->num_rows();
	}
	
	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('playlist_item_id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function save($data)
	{	
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('playlist_item_id', $id);
		$this->db->delete($this->table);
	}
	
	public function approve_pending_playlist_item($id)
	{
		//$sql = "UPDATE ".$this->table." SET on_live = FALSE"; // update all to false
		//$this->db->query($sql);
		
		$sql = "UPDATE ".$this->table." SET active = not active WHERE playlist_item_id = " . (int)$id; // now update the specified id to TRUE
		$this->db->query($sql);
		
		return $this->db->affected_rows();

	}
	
	public function is_valid_to_save_time($playlist_id)
	{
	

	$this->db->select('start_time, end_time' );
			$this->db->from($this->table);
		$this->db->where('playlist_id',$playlist_id);

		$query = $this->db->get();
		error_log(json_encode( $query->result()).'hhhhhhhhhhhhhhhh');
		return $query->result();	
	
		//$this->db->select(' count(*) = 0 as valid ')
				//->from($this->table)
				//->where($start_time." <= end_time ");
				//->where(" playlist_id = ".$playlist_id." AND ( (".$start_time." <= end_time) and (start_time <= ".$end_time."))");

		//$query = $this->db->get();

		//return $query->row();
	}	


}
