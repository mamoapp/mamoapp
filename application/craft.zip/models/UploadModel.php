<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UploadModel extends CI_Model {

	public function testMain()
	{
		echo 'this is upload model';
	}
	
	// participant_id	filename	local_filename	file_type	file_size
	public function insertAsset($data)
	{
		return $this->db->insert("assets", $data);
	}
	
	public function fetchAsset()
	{
		$this->db->select("*");
		$this->db->from("assets");
		$query = $this->db->get();
		return $query;
	}
	
	public function fetchAssetById($id)
	{
		$this->db->where("assets_id", $id);
		$query = $this->db->get("assets");
		return $query;
	} 

	

	public function updateAsset($data, $id)
	{
		$this->db->where("assets_id", $id);
		$this->db->update("assets", $data);
	}
	

	


}
