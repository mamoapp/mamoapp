<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Watch_live_model extends CI_Model {

	var $table = 'playlist_item';
	var $column_order = array(null,'name',null); //set column field database for datatable orderable
	var $column_search = array('name'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('playlist_item_id' => 'desc'); // default order 

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query()
	{
		
		$this->db->from($this->table);
		$i = 0;
	
		foreach ($this->column_search as $item) // loop column 
		{
			if($_POST['search']['value']) // if datatable send POST for search
			{
				
				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $_POST['search']['value']);
				}
				else
				{
					$this->db->or_like($item, $_POST['search']['value']);
				}

				if(count($this->column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables($parent_id)
	{
		$this->_get_datatables_query();
		$this->db->where('playlist_id', $parent_id);

		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}
	
	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('playlist_item_id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function save($data)
	{	
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('playlist_item_id', $id);
		$this->db->delete($this->table);
	}
	
	public function fetch_item_info(){	
	
		$query_tz = $this->db->query("SET SESSION time_zone = '+8:00';");
		$query_info = $this->db->query("SELECT a.playlist_id, b.playlist_item_id, b.template_id, a.ticker_message,
										curtime() as time_now,
										DATE_FORMAT(a.start_time,'%H:%i:%s') as start_time, DATE_FORMAT(a.end_time,'%H:%i:%s') as end_time,
										c.local_filename as p1_local_filename, c.file_type as p1_file_type, c.text_message as p1_text_message,
										d.local_filename as p2_local_filename, d.file_type as p2_file_type, d.text_message as p2_text_message,
										e.local_filename as p3_local_filename, e.file_type as p3_file_type, e.text_message as p3_text_message
										FROM playlist a
										LEFT JOIN playlist_item b ON a.playlist_id = b.playlist_id
										LEFT JOIN assets c ON b.primary_asset_id = c.assets_id
										LEFT JOIN assets d ON b.secondary_asset_id = d.assets_id
										LEFT JOIN assets e ON b.tertiary_asset_id = e.assets_id
										WHERE a.on_live and
										(DATE_FORMAT(a.start_time,'%H:%i:%s') <= curtime() and curtime() <= DATE_FORMAT(a.end_time,'%H:%i:%s') )
										limit 1;");
		$rows = $query_info->row();	
	}


}
