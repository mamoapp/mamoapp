<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginModel extends CI_Model {

	public function testMain()
	{
		echo 'this is login model';
	}
	
	public function insertParticipant($data)
	{
		return $this->db->insert("participant", $data);
	}
	
	public function fetchParticipant()
	{
		$this->db->select("*");
		$this->db->from("participat");
		$query = $this->db->get();
		return $query;
	}
	
	public function fetchParticipantById($id)
	{
		$this->db->where("participant_id", $id);
		$query = $this->db->get("participant");
		return $query;
	} 
	
	public function fetchParticipantByEmailPassword($email, $password)
	{
		$this->db->where("email_address", $email);
		$this->db->where("password", $password);
		$query = $this->db->get("participant");
		return $query;
	} 
	
	public function fetchParticipantByEmail($email)
	{
		$this->db->where("email_address", $email);
		$query = $this->db->get("participant");
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return NULL;
		}
		
		return $query;
	} 

	public function updateParticipant($data, $id)
	{
		$this->db->where("participant_id", $id);
		$this->db->update("participant", $data);
	}
	
	public function canLogin($email, $password)
	{
		$this->db->where("email_address", $email);
		if(isset($password)){
			$this->db->where("password", $password);
		}
		$query = $this->db->get("participant");

		if($query->num_rows() > 0){
			return true;
		}else{
			return false;
		}
	}
	
	public function canCreateNewParticipant($email)
	{
		$this->db->where("email_address", $email);
		$query = $this->db->get("participant");

		if($query->num_rows() == 0){
			return true;
		}else{
			return false;
		}
	}
	


}
