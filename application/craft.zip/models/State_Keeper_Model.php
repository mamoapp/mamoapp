<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class State_Keeper_Model extends CI_Model {

	public function testMain()
	{
		echo 'this is login model';
	}
	
	public function insertParticipant($data)
	{
		$this->db->insert("participant", $data);
	}
	
	public function fetch_sql_time()
	{
		$this->db->select("now() as date_time");
		$query = $this->db->get();
		return $query->result;
	}
	
	

}
