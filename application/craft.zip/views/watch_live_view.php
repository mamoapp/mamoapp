<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Noti-PI</title>


	
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

	<!-- <link href="<?php //echo base_url('bootstrap/dist/css/fade_orj.css');?>" rel="stylesheet"> -->

	
	
    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

	
    <!-- DataTables CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.css');?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.css');?>" rel="stylesheet">

	
    <link href="<?php echo base_url('bootstrap/datatables/css/dataTables.bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('bootstrap/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
	
	
	<link href="<?php echo base_url('bootstrap/dist/css/fadeorj.css');?>" rel="stylesheet">

    <link href="<?php echo base_url('bootstrap/dist/css/full-slider.css');?>" rel="stylesheet">
	
	<style>
		#myDiv.fullscreen{
			z-index: 9999; 
			width: 100%; 
			height: 100%; 
			position: fixed; 
			top: 0; 
			left: 0; 
		 }
	</style>
</head>

<body>
    <div id="wrapper">
        <?php include 'navigation.php'; ?>

	<!-- Page Content -->
	<div id="page-wrapper">	
	
		<!-- Slide show -->
		<div id="myCarousel" class="carousel slide">
			<!-- Indicators 
			<ol class="carousel-indicators">
				<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				<li data-target="#myCarousel" data-slide-to="1"></li>
			</ol>-->

			<!-- Wrapper for Slides -->
			<div id="myDiv" class="carousel-inner">
				<div id="myDiv">
					<!-- In here will be inserted the items -->
				</div>
			</div>
		</div>
				
		<!-- Date Time -->
		<div id="date_time" style="font-size: 1.8vw;" class="alert-info col-xs-12 col-md-12 fade-in four">
		</div>				
				
		<?php	
		$query_tz = $this->db->query("SET SESSION time_zone = '+8:00';");
		$query_ticker = $this->db->query("SELECT a.playlist_id, a.ticker_message
								FROM playlist a
								WHERE a.on_live and
								(DATE_FORMAT(a.start_time,'%H:%i:%s') <= curtime() and curtime() <= DATE_FORMAT(a.end_time,'%H:%i:%s') )
								;");
		$ticker = $query_ticker->row();
		?>					
		<!-- Ticker should only show once-->
		<div style="font-size: 1.5vw; height:2vw" class="alert-danger col-xs-12 col-md-12 fade-in four" >
			<strong>
			<marquee>
			<p>
			<?php if(isset($ticker)) echo $ticker->ticker_message;?>
			</p>
			</marquee>
			</strong>
		</div>	
			
    </div>
    <!-- /#page-wrapper -->

<!-- jQuery -->
<!-- <script src="../vendor/jquery/jquery.min.js"></script>-->

	<script src="<?php echo base_url('bootstrap/jQuey/jquery-3.2.1.min.js');?>" type="text/javascript"></script>


<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>



<!-- DataTables JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/datatables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.js');?>"></script>

<script src="<?php echo base_url('bootstrap/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>

<script type="text/javascript">
	var current_id = -1;
	function refresh(){
		$('#myCarousel').carousel({ 
			interval: 15000,
		 });
		
		$.ajax({
			url : "<?php echo site_url('Watch_live/fetch_item_info'); ?>",
			type: "GET",
			dataType: "JSON",
			success: function(data)
			{
				if(data.temp_unique_id != current_id){
					current_id = data.temp_unique_id;
					$.ajax({
						url: "<?php echo site_url('Watch_live/ajax_live_view'); ?>",
						success: function(data){							
							$("#myDiv").html(data);
						}});
						
				}
				
				setTimeout(function(){
					refresh(); //this will send request again and again;
				}, 15000);
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				alert('timeout'+jqXHR.responseText);
			}
		});
		
		
		
	}
	function time_refresh(){
		$.ajax({
			url : "<?php echo site_url('Watch_live/real_date_time'); ?>",
			type: "GET",
			dataType: "JSON",
			success: function(data)
			{
				$("#date_time").html('<strong style="float:right;">'+data.date_now+' '+data.time_now+'</string>');
				setTimeout(function(){
					time_refresh(); //this will send request again and again;
				}, 1000);
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				//alert('timeout');
			}
		});
	}
	
	jQuery(document).ready(function(){
		refresh();
		time_refresh();
	
		//setTimeout(function(){
			//$('.carousel').carousel({
			 // interval: 5000
			//})
		//}, 1000);

	});			

</script>	


</body>

</html>
