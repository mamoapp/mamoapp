<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Noti-PI</title>

	<script src="<?php echo base_url('bootstrap/jQuey/jquery-3.2.1.min.js');?>" type="text/javascript"></script>

	
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">


    <!-- File Upload -->
    <!--<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">-->
    <link href="<?php echo base_url('bootstrap/file/css/fileinput.css');?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url('bootstrap/file/themes/explorer/theme.css');?>" media="all" rel="stylesheet" type="text/css"/>


    <script src="<?php echo base_url('bootstrap/file/js/plugins/sortable.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/fileinput.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/locales/fr.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/locales/es.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/themes/explorer/theme.js');?>" type="text/javascript"></script>
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" type="text/javascript"></script>-->


</head>

<body>

    <div id="wrapper">

		<?php include 'navigation.php'; ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="page-header">Media Manager</h2>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"><i class="fa fa-list-alt fa-fw"></i></a>Upload File
                                </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in">
                                <div class="panel-body">
                                    <form enctype="multipart/form-data">
                                        <input id="multfilesid" name="fileuploads[]" type="file" multiple>
                                        <br>
                                    </form>
                                </div>
                            </div>
                        </div>



                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <!-- <script src="../vendor/jquery/jquery.min.js"></script>-->

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>

    <!-- File Upload -->
    <script>
        $(document).ready(function () {

            $("#multfilesid").fileinput({
				'theme': 'explorer',
				'showRemove': false, // hide remove button
                'allowedFileExtensions': ['jpg', 'png', 'gif', 'mp4', 'ogg', 'webm'],
                'uploadAsync': false,
				'uploadUrl': "<?php echo base_url() ?>index.php/Upload/fileinput_upload"
			
            });

        });
		

    </script>


</body>

</html>
