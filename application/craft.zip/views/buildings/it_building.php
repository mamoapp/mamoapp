<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SPCF Map Search</title>

	<script src="<?php echo base_url('bootstrap/jQuey/jquery-3.2.1.min.js');?>" type="text/javascript"></script>

	
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

	
    <!-- DataTables CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.css');?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.css');?>" rel="stylesheet">

	
    <link href="<?php echo base_url('bootstrap/datatables/css/dataTables.bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('bootstrap/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
	
	
</head>

<body>

    <div id="wrapper">
        <!-- Page Content -->
        
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12">				
					<br/>
					<!--
					<div class="alert alert-info">
						<b>SPCF Map Search is from Start point to End point.</b>
					</div>		-->
					<div class="panel panel-red">
						<div class="panel-heading">
							<h4 class="panel-title ">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
								<h4><i class="fa fa-building-o fa-fw"></i><b>I.T. BUILDING </b></h4></a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in">
							<div class="panel-body">

							
								<div class="panel-body">
									<img style="margin:0px auto;display:block" src="<?php echo base_url().'assets/it_building.jpg' ;?>" alt="MCB BUILDING" width="190" height="250">

									<br/>
									<div class="panel panel-warning">
										<div class="panel-heading">
											<h4>
												<button type="button" class="btn btn-info btn-circle btn-lg">GF</button>
												GROUND FLOOR
											</h4>
										</div>
										<div class="panel-body">
											<ul>					
												<li>LOBBY</li>
												<li>UTILITY ROOM</li>
											</ul>									
										</div>
									</div>
									
									<div class="panel panel-warning">
										<div class="panel-heading">
											<h4>
												2ND FLOOR
												<button type="button" class="btn btn-primary btn-circle btn-lg">2F</button>
												
											</h4>
										</div>
										<div class="panel-body">
											<ul>														
												<li>A.V.J LIBRARY</li>
												<li>CONFERENCE ROOM</li>
												<li>SEMINAR ROOM</li>
												<li>OFFICE OF EXTERNAL RELATION & DEVELOPMENT</li>
												<li>OFFICE OF THE PRESIDENT</li>
												<li>EXECUTIVE VICE PRESIDENT OFFICE</li>
												<li>BOARD ROOM</li>
												<li>RESEARCH LABORATORY </li>
												<li>ICTDU</li>
											</ul>									
										</div>
									</div>
									
									<div class="panel panel-warning">
										<div class="panel-heading">
											<h4>
												<button type="button" class="btn btn-success btn-circle btn-lg">3F</button>
												3RD FLOOR
											</h4>
										</div>
										<div class="panel-body">
											<ul>																
												<li>CISCO Laboratory</li>
												<li>Server Room</li>
												<li>Control Room</li>
												<li>CISCO Hands-On Lab</li>
												<li>Open Source Laboratory</li>
												<li>Animation Laboratory</li>
												<li>Mac Laboratory</li>
												<li>Laboratory 3</li>
												<li>Case Room</li>
											</ul>									
										</div>
									</div>
									
									<div class="panel panel-warning">
										<div class="panel-heading">
											<h4>
												4TH FLOOR
												<button type="button" class="btn btn-warning btn-circle btn-lg">4F</button>
											</h4>
										</div>
										<div class="panel-body">
											<ul>					
												<li>THE THEATRE</li>
											</ul>									
										</div>
									</div>
								
								</div>
								<!-- /.panel-body -->
							
							</div>
						</div>
					</div>						
	
	
				
				
				</div>
				<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
		</div>
		<!-- /.container-fluid -->
	
    </div>
    <!-- /#wrapper -->

<!-- jQuery -->
<!-- <script src="../vendor/jquery/jquery.min.js"></script>-->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>



<!-- DataTables JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/datatables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.js');?>"></script>



<script src="<?php echo base_url('bootstrap/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
	
	
	
	
<script type="text/javascript">


$(document).ready(function() {
    //set input/textarea/select event when change value, remove class error and remove text help block 
    $("input").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("textarea").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("select").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });

	
	
});

function doesFileExist(urlToFile) {
    var xhr = new XMLHttpRequest();
    xhr.open('HEAD', urlToFile, false);
    xhr.send();
     
    if (xhr.status == "404") {
        return false;
    } else {
        return true;
    }
}


function playVideo(video){
    window.JSInterface.startVideo(video);
}

function map_search() { 
  var _baseUrl = "<?php echo base_url().'assets/'?>";
		  
  var _startPoint = $('#start_point').val();
  var _endPoint = $('#end_point').val();

  if(_startPoint === _endPoint){
	$('.modal-text-message').text('Start Point and End Point should not be the same.');
	$('#modal_form').modal('show');
	$('#videopreview').trigger('pause');
  }else{
	var result = doesFileExist(_baseUrl+_startPoint+'_'+_endPoint+'.mp4');
	if (result == true) {
		$('.modal-text-message').text('Let\'s go from '+_startPoint+' to '+_endPoint);
		$('#modal_form').modal('show');
		var video = document.getElementById('videopreview');
		var source = document.createElement('source');

		source.setAttribute('src', _baseUrl+_startPoint+'_'+_endPoint+'.mp4');

		video.appendChild(source);
		video.play()
	} else {
		$('.modal-text-message').text('File Route still not exists!');
		$('#modal_form').modal('show');
	}
	
  }


}





</script>
<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">NOTICE</h3>
            </div>
            <div class="modal-body form">
				<p class="modal-text-message"></p>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->




</body>

</html>
