<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>

    <div id="wrapper">

		<?php include 'navigation.php'; ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div id="main_dashboard_div" class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Blank</h1>
						
						
						

                    </div>
                    <!-- /.col-lg-12 -->
                </div>
				
				

                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
	
	
	<script>
		function select_side_menu(selection){
			if('Media Manager' === selection){
				$.ajax({
					type: "POST",
					url: "<?php echo base_url('index.php/State_Keeper/redirect_media_manager'); ?>",
					success: function(data){
						$("#main_dashboard_div").html(data);
					}
				});
			}else if('Schedule' === selection){
				$.ajax({
					type: "POST",
					url: "<?php echo base_url('index.php/State_Keeper/redirect_schedule'); ?>",
					success: function(data){
						$("#main_dashboard_div").html(data);
					}
				});
			}else if('Date Time' === selection){
				$.ajax({
					type: "POST",
					url: "<?php echo base_url('index.php/State_Keeper/redirect_date_time'); ?>",
					success: function(data){
						$("#main_dashboard_div").html(data);
					}
				});
			}else if('Monitor' === selection){
				$.ajax({
					type: "POST",
					url: "<?php echo base_url('index.php/State_Keeper/redirect_monitor'); ?>",
					success: function(data){
						$("#main_dashboard_div").html(data);

						
						
					}
				});
			}
			
		}

	</script>

	<!-- jQuery -->
    <script src="<?php echo base_url('bootstrap/vendor/jquery/jquery.min.js');?>"></script>
<script type = "text/javascript" src = "//cdnjs.cloudflare.com/ajax/libs/jquery.form/3.51/jquery.form.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>

	<!-- Upload-->

	<script>                    
        jQuery(document).ready(function($) {

            var options = {
                beforeSend: function(){
                    // Replace this with your loading gif image
                    $(".upload-image-messages").html('<p><img src = "<?php echo base_url() ?>images/loading.gif" class = "loader" /></p>');
                },
                complete: function(response){
                    // Output AJAX response to the div container
                    $(".upload-image-messages").html(response.responseText);
                    $('html, body').animate({scrollTop: $(".upload-image-messages").offset().top-100}, 150);
                    
                }
            };  
            // Submit the form
            $(".upload-image-form").ajaxForm(options);  

            return false;
            
        });
	</script>
	
	
	
	<script>
		function img(src) {
			var el = document.createElement('img');
			el.src = src;
			return el;
		}

		function vid() {
			//Accepts any number of ‘src‘ to a same video ('.mp4', '.ogg' or '.webm')
			var el = document.createElement('video');
			var source = document.createElement('source');
			for (var i = 0; i < arguments.length; i++) {
				source.src = arguments[i];
				source.type = "video/" + arguments[i].split('.')[arguments[i].split('.').length - 1];
				el.appendChild(source);
			}
			el.onplay = function () {
				clearInterval(sliding);
			};
			el.onended = function () {
				sliding = setInterval(rotateimages, 10000);
				rotateimages();
			};
			return el;
		}

		var galleryarray = [img('<?php echo base_url(); ?>assets/Koala.jpg'),
							vid('<?php echo base_url(); ?>assets/sample_video.mp4', '<?php echo base_url(); ?>assets/sample_video.mp4')
						   ];
		var curimg = 1;

		function rotateimages() {
			$("#slideshow").fadeOut("slow");
			setTimeout(function () {
				curimg = (curimg < galleryarray.length - 1) ? curimg + 1 : 0
				document.getElementById('slideshow').innerHTML = '';
				galleryarray[curimg].style.width = "100%";
				galleryarray[curimg].style.height = "100%";
				document.getElementById('slideshow').appendChild(galleryarray[curimg]);
				if (galleryarray[curimg].tagName === "VIDEO") {
					galleryarray[curimg].play();
				}
				$("#slideshow").fadeIn("slow");
			}, 1000);
		}

		var sliding;
		function playSlideShow(){
			curimg = 1;
			sliding = setInterval(rotateimages, 10000);
			rotateimages();
			//FullScreen won't work in jsFiddle's iframe
			document.getElementById('slideshow').onclick = function () {
				if (this.requestFullscreen) {
					this.requestFullscreen();
				} else if (this.msRequestFullscreen) {
					this.msRequestFullscreen();
				} else if (this.mozRequestFullScreen) {
					this.mozRequestFullScreen();
				} else if (this.webkitRequestFullscreen) {
					this.webkitRequestFullscreen();
				}
			}
		}
		function stopSlideShow(){
			curimg = 1;
		}

	</script>
	
	
</body>

</html>
