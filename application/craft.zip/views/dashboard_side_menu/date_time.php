<br/>
<div class="alert alert-success">
 <a href="#" class="alert-link">DATE TIME VIEW</a>.
</div>
