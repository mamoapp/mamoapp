<br/>
<div class="alert alert-success">
 <a href="#" class="alert-link">SCHEDULE VIEW</a>.
</div>
