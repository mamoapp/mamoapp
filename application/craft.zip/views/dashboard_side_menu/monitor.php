<div id="slideshow" class="img-responsive"></div>

