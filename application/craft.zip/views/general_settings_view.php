<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Noti-PI</title>

	<script src="<?php echo base_url('bootstrap/jQuey/jquery-3.2.1.min.js');?>" type="text/javascript"></script>

	
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

	
    <!-- DataTables CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.css');?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.css');?>" rel="stylesheet">

	
    <link href="<?php echo base_url('bootstrap/datatables/css/dataTables.bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('bootstrap/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
	
	
</head>

<body>

    <div id="wrapper">

        <?php include 'navigation.php'; ?>

        <!-- Page Content -->
        <div id="page-wrapper">
																						
                <div class="row">
                    <div class="col-lg-12">				
						<br/>
						<div class="alert alert-info">
							<b>NOTE:</b> Here you can modify the settings needed for the application.
						</div>								
						
						<div class="panel panel-default">

							<!-- .panel-heading -->
							<div class="panel-body">
								<div class="panel-group" id="accordion">
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
												<p  style="text-align:right;">
													<span style="float:left;"><i class="fa fa-user fa-fw" ></i>
														User Permissions</span>
													<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
													<i class="glyphicon glyphicon-folder-open"></i></a>
												</p>									
							
											</h4>
										</div>
										<div id="collapseOne" class="panel-collapse collapse in">
											<div class="panel-body">
												
												
												
												<table id="table" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
													<thead>
														<tr>
															<th style="width:15%;">First Name</th>
															<th style="width:15%;">Last Name</th>
															<th style="width:20%;">Email Address</th>
															<th style="width:10%;">Year Level</th>
															<th style="width:10%;">Course</th>															
															<th style="width:20%;">Permission</th>
															<th style="width:10%;">Action</th>
														</tr>
													</thead>
													<tbody>
													</tbody>
												</table>
												
												
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
												<p  style="text-align:right;">
													<span style="float:left;"><i class="fa fa-gear fa-fw" ></i>
														General Settings</span>
													<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
													<i class="glyphicon glyphicon-folder-open"></i></a>
												</p>
											</h4>
										</div>
										<div id="collapseTwo" class="panel-collapse collapse">
											<div class="panel-body">
											
										
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
												<p  style="text-align:right;">
													<span style="float:left;">Other</span>
													<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
													<i class="glyphicon glyphicon-folder-open"></i></a>
												</p>
											</h4>
										</div>
										<div id="collapseThree" class="panel-collapse collapse">
											<div class="panel-body">
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- .panel-body -->
						</div>
						<!-- /.panel -->

						
											
					
					
					
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!-- jQuery -->
<!-- <script src="../vendor/jquery/jquery.min.js"></script>-->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>



<!-- DataTables JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/datatables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.js');?>"></script>



<script src="<?php echo base_url('bootstrap/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
	
	
	
	
<script type="text/javascript">

var save_method; //for save method string
var table;
var base_url = '<?php echo base_url();?>';

$(document).ready(function() {

    //datatables
    table = $('#table').DataTable({ 
        "responsive": true,
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.

        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('Participant/ajax_list')?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
            { 
                "targets": [ 0 ], //first column
                "orderable": false, //set not orderable
            },
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },

        ],

    });

    //datepicker
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,  
    });

    //set input/textarea/select event when change value, remove class error and remove text help block 
    $("input").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("textarea").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("select").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });


    //check all
    $("#check-all").click(function () {
        $(".data-check").prop('checked', $(this).prop('checked'));
    });

});

function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}

function remove_as_admin(participant_id)
{
    if(confirm('Are you sure to let this user to have Admin priviledges?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('Participant/remove_as_admin')?>/"+participant_id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
				 alert( jqXHR.responseText);


            }
        });

    }
}


function mark_as_admin(participant_id)
{
    if(confirm('Are you sure to let this user to have Admin priviledges?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('Participant/mark_as_admin')?>/"+participant_id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
				 alert( jqXHR.responseText);


            }
        });

    }
}

function edit_participant(participant_id)
{
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string


    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Participant/ajax_edit')?>/" + participant_id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
			$('[name="id"]').val(data.participant_id);
			$('[name="user_type"]').val(data.user_type_id);
			$('[name="first_name"]').val(data.first_name);
			$('[name="last_name"]').val(data.last_name);
			$('[name="email"]').val(data.email_address);
			$('[name="password"]').val(data.password);
			$('[name="year_level"]').val(data.year_level);
			$('[name="course"]').val(data.course);

			
								
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit User'); // Set title to Bootstrap modal title


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}


function ajax_delete(participant_id)
{
    if(confirm('Are you sure you want to permanently delete this User?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('Participant/ajax_delete')?>/"+participant_id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

    }
}

function save()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;

    url = "<?php echo site_url('Participant/ajax_update')?>";


    // ajax adding data to database
    var formData = new FormData($('#form')[0]);
    $.ajax({
        url : url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $('#modal_form').modal('hide');
                reload_table();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update dataaaa'+errorThrown+jqXHR.responseText);
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}
</script>
	
	
	
	<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Edit User</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
				<input type="hidden" value="" name="id"/> 
					<fieldset>					
						
						<div class="form-group">
							<label class="control-label col-md-3">Type of User</label>
                            <div class="col-md-9">                           
								<select name="user_type" class="form-control" style="width:50%">
									<option value="" label="Select Type of User" disabled selected></option>
									<?php
									foreach($user_type_look_up as $user_type)
									{
										?>
										<option value="<?php echo $user_type->look_up_id?>"><?php echo $user_type->description?></option>
										<?php
									}
									?>
								</select>
                                <span class="help-block"></span>								
							</div>							
						</div>	
						
						<div class="form-group">
							<label class="control-label col-md-3">First Name</label>
                            <div class="col-md-9">
                                <input name="first_name" placeholder="First Name" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
						</div>
						<div class="form-group">
							<label class="control-label col-md-3">Last Name</label>
                            <div class="col-md-9">
                                <input name="last_name" placeholder="Last Name" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
						</div>								
						<div class="form-group">
							<label class="control-label col-md-3">E-mail</label>
                            <div class="col-md-9">
                                <input name="email" placeholder="E-mail" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
						</div>
						<div class="form-group">
							<label class="control-label col-md-3">Password</label>
                            <div class="col-md-9">
                                <input name="password" placeholder="Password" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
						</div>	
											
						<div class="form-group">
							<label class="control-label col-md-3">Year Level</label>
                            <div class="col-md-9">                           
								<select name="year_level" class="form-control" style="width:50%">
									<option value="" label="Select Year Level" disabled selected></option>
									<?php
									foreach($year_level_look_up as $year_level)
									{
										?>
										<option value="<?php echo $year_level->look_up_id?>"><?php echo $year_level->description?></option>
										<?php
									}
									?>
								</select>
                                <span class="help-block"></span>								
							</div>							
						</div>	
						<div class="form-group">
							<label class="control-label col-md-3">Course</label>
                            <div class="col-md-9">
                                <input name="course" class="form-control" placeholder="Course" type="text">
                                <span class="help-block"></span>
                            </div>
						</div>
																	
					</fieldset>
				</form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="save();" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->	
	

	


<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
		<video id="videopreview" width="100%" controls muted >
			<source src="" type="video/mp4">
			Your browser does not support the video tag.
		</video>
      </div>
    </div>
  </div>
</div>
</body>

</html>
