aaa<div class="row show-grid"  onclick="full_screen();">
							<!-- Templte 1 -->
							<div id="t1_primary_div" style="border:none; background:white;" class="col-xs-12 col-md-12" >
							</div>
							
							<!-- Templte 2 -->
							<div id="t2_primary_div" style="border:none; background:white;" class="col-xs-6 col-md-6" >
							</div>
							<div id="t2_secondary_div" style="border:none; background:white;" class="col-xs-6 col-md-6" >
							</div>
							
							<!-- Templte 3 -->
							<div id="t3_primary_div" style="border:none; background:white;" class="col-xs-9 col-md-9" >
							</div>
							<div id="t3_secondary_div" style="border:none; background:white;" class="col-xs-3 col-md-3" >
							</div>
							<div id="t3_tertiary_div" style="border:none; background:white;" class="col-xs-3 col-md-3" >
							</div>
							<div id="blank" style="border:none; background:white;" class="col-xs-9 col-md-9" >
							</div>
							<br/>
						   <div id="datetime" style="color:blue; font-size:50px; float:right;"></div>
						   <br/>
						</div>
<script>
<?php
					$query = $this->db->query("SELECT a.playlist_id, b.template_id, 
												DATE_FORMAT(b.start_time,'%H') as start_hour, DATE_FORMAT(b.start_time,'%i') as start_min, 
												DATE_FORMAT(b.end_time,'%H') as end_hour, DATE_FORMAT(b.end_time,'%i') as end_min, 
												c.local_filename as p1_local_filename, c.file_type as p1_file_type, c.text_message as p1_text_message,
												d.local_filename as p2_local_filename, d.file_type as p2_file_type, d.text_message as p2_text_message,
											    e.local_filename as p3_local_filename, e.file_type as p3_file_type, e.text_message as p3_text_message
												FROM playlist a
												LEFT JOIN playlist_item b ON a.playlist_id = b.playlist_id
												LEFT JOIN assets c ON b.primary_asset_id = c.assets_id
												LEFT JOIN assets d ON b.secondary_asset_id = d.assets_id
												LEFT JOIN assets e ON b.tertiary_asset_id = e.assets_id
												WHERE a.on_live order by b.start_time ;");
					foreach ($query->result() as $row)
					{

				?>		
						

						// WHEN START SHOW IMAGE
						var now = new Date();
						//year, month 0-11, date, hour, min (can add ,sec,msec)
						var eta_ms = new Date(now.getFullYear(), now.getMonth(), now.getDate(), <?php echo $row->start_hour;?>, <?php echo $row->start_min;?>).getTime() - Date.now();
						var eta_ms_end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), <?php echo $row->end_hour;?>, <?php echo $row->end_min;?>).getTime() - Date.now();

						if(eta_ms <= now && now <= eta_ms_end){
						//var timeout = setTimeout(function(){
							var template_id = <?php echo $row->template_id;?>
							
							if(template_id == 1){
								document.getElementById("t2_primary_div").innerHTML = '';
								document.getElementById("t2_secondary_div").innerHTML = '';
								var isP1Text = <?php echo $row->p1_file_type <=> 'text' ;?>; 
								if(isP1Text == 0){
									document.getElementById("t1_primary_div").innerHTML = '<h1 style="font-size:50px; text-align: center;"><?php echo $row->p1_text_message?></h1>';
								}else{
									document.getElementById("t1_primary_div").innerHTML = '<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" class="img-fluid" alt="No image" style="height: 590px; width: 100%; display: block;"/>';
								}

							}else if(template_id == 2){
								//clear out
								document.getElementById("t1_primary_div").innerHTML = '';
								var isP1Text = <?php echo $row->p1_file_type <=> 'text' ;?>; 
								if(isP1Text == 0){
									document.getElementById("t2_primary_div").innerHTML = '<h1 style="font-size:50px; text-align: center;"><?php echo $row->p1_text_message?></h1>';
								}else{
									document.getElementById("t2_primary_div").innerHTML = '<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" class="img-fluid" alt="No image" style="height: 570px; width: 100%; display: block;"/>';
								}
								
								var isP2Text = <?php echo $row->p2_file_type <=> 'text' ;?>; 
								if(isP2Text == 0){
									document.getElementById("t2_secondary_div").innerHTML = '<h1 style="font-size:50px; text-align: center;"><?php echo $row->p2_text_message?></h1>';
								}else{
									document.getElementById("t2_secondary_div").innerHTML = '<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" class="img-fluid" alt="No image" style="height: 570px; width: 100%; display: block;"/>';
								}
							}else if(template_id == 3){
								//clear out
								document.getElementById("t1_primary_div").innerHTML = '';
								document.getElementById("t2_primary_div").innerHTML = '';
								document.getElementById("t2_secondary_div").innerHTML = '';
								var isP1Text = <?php echo $row->p1_file_type <=> 'text' ;?>; 
								if(isP1Text == 0){
									document.getElementById("t3_primary_div").innerHTML = '<h1 style="font-size:50px; text-align: center;"><?php echo $row->p1_text_message?></h1>';
								}else{
									document.getElementById("t3_primary_div").innerHTML = '<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" class="img-fluid" alt="No image" style="height: 600px; width: 100%; display: block;"/>';
								}
								
								var isP2Text = <?php echo $row->p2_file_type <=> 'text' ;?>; 
								if(isP2Text == 0){
									document.getElementById("t3_secondary_div").innerHTML = '<h1 style="font-size:50px; text-align: center;"><?php echo $row->p2_text_message?></h1>';
								}else{
									document.getElementById("t3_secondary_div").innerHTML = '<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" class="img-fluid" alt="No image" style="height: 289px; width: 100%; display: block;"/>';
								}
								
								var isP3Text = <?php echo $row->p3_file_type <=> 'text' ;?>; 
								if(isP3Text == 0){
									document.getElementById("t3_tertiary_div").innerHTML = '<h1 style="font-size:50px; text-align: center;"><?php echo $row->p3_text_message?></h1>';
								}else{
									document.getElementById("t3_tertiary_div").innerHTML = '<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p3_local_filename; ?>" class="img-fluid" alt="No image" style="height: 289px; width: 100%; display: block;"/>';
								}
							}
							
						//}, eta_ms);
						}else{
						
						// WHEN END DEFAULT IMAGE notipi_logo
						//var now = new Date();
						//year, month 0-11, date, hour, min (can add ,sec,msec)
						//var eta_ms = new Date(now.getFullYear(), now.getMonth(), now.getDate(), <?php echo $row->end_hour;?>, <?php echo $row->end_min;?>).getTime() - Date.now();
						//var timeout = setTimeout(function(){
							document.getElementById("t1_primary_div").innerHTML = '<img src="<?php echo base_url(); ?>assets/notipi_logo.png" class="img-fluid" alt="No image" style="height: 600px; width: 100%; display: block;"/>';
							document.getElementById("t2_primary_div").innerHTML = '';
							document.getElementById("t2_secondary_div").innerHTML = '';

						//}, eta_ms);
						}
				<?php
					}
				?>		
				</script>