<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Noti-PI</title>

	<script src="<?php echo base_url('bootstrap/jQuey/jquery-3.2.1.min.js');?>" type="text/javascript"></script>

	
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

	
    <!-- DataTables CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.css');?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.css');?>" rel="stylesheet">
	
    <link href="<?php echo base_url('bootstrap/datatables/css/dataTables.bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('bootstrap/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
	
	
	<!-- File Upload -->
    <!--<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">-->
    <link href="<?php echo base_url('bootstrap/file/css/fileinput.css');?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url('bootstrap/file/themes/explorer/theme.css');?>" media="all" rel="stylesheet" type="text/css"/>


    <script src="<?php echo base_url('bootstrap/file/js/plugins/sortable.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/fileinput.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/locales/fr.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/locales/es.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/themes/explorer/theme.js');?>" type="text/javascript"></script>
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" type="text/javascript"></script>-->

	
</head>

<body>

    <div id="wrapper">

        <?php include 'navigation.php'; ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">				
						<br/>
						<div class="alert alert-info">
							<b>NOTE:</b> Here you can add an asset that can be used in creating a playlist. Uploading assets goes first before queuing them in th playlist.
							<br/><i><b>TIP:</b> You can click file image display to preview/update asset.</i>
						</div>	
								
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"><i class="fa fa-list-alt fa-fw"></i></a>Assets
                                </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in">
                                <div class="panel-body">
                                    <!--<button class="btn btn-success" title="Add New Asset" onclick="add_asset()"><i class="glyphicon glyphicon-plus"></i> Add New Asset</button>
									-->
									<li class="dropdown btn" >
										<a class="dropdown-toggle btn btn-success" data-toggle="dropdown" href="#">
											<i class="glyphicon glyphicon-plus"></i> Add New Asset
										</a>
										<ul class="dropdown-menu dropdown-messages">
											<li><a href="#"onclick="add_text_message();"><i class="fa fa-font fa-fw"></i> Text</a>
											</li>
											<li class="divider"></li>
											<li><a href="#" onclick="add_asset();"><i class="fa fa-image fa-fw"></i>Upload File</a>
											</li>

										</ul>									
									</li>

									<button class="btn btn-default" onclick="reload_table()"><i class="glyphicon glyphicon-refresh"></i> Reload</button>
									<button class="btn btn-danger" onclick="bulk_delete()"><i class="glyphicon glyphicon-trash"></i>Delete</button>
									<br />
									<br />
									<table id="table" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th style="width:5%;"><input type="checkbox" id="check-all"></th>
												<th style="width:10%;">File</th>																					
												<th style="width:30%;">File Name</th>
												<th style="width:25%;">Type</th>		
												<th style="width:20%;">Size</th>										
												
												<th style="width:10%;">Action</th>
											</tr>
										</thead>
										<tbody>
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>						
						
						
						
						
						
						
						
						
					
					
					
					
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!-- jQuery -->
<!-- <script src="../vendor/jquery/jquery.min.js"></script>-->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>



<!-- DataTables JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/datatables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.js');?>"></script>

<script src="<?php echo base_url('bootstrap/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
	
	

<script type="text/javascript">

var save_method; //for save method string
var table;
var base_url = '<?php echo base_url();?>';


$(document).ready(function() {

    //datatables
    table = $('#table').DataTable({ 
        "responsive": true,
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.

        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('AssetController/ajax_list')?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
            { 
                "targets": [ 0 ], //first column
                "orderable": false, //set not orderable
            },
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },

        ],

    });

    //datepicker
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,  
    });

    //set input/textarea/select event when change value, remove class error and remove text help block 
    $("input").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("textarea").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("select").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });


    //check all
    $("#check-all").click(function () {
        $(".data-check").prop('checked', $(this).prop('checked'));
    });
	
	
	$(document).on('click','#pop_image',function(){
		$('.imagepreview').attr('src', $(this).find('img').attr('src'));
			$('#imagemodal').modal('show');   
	});
	
	$(document).on('click','#pop_video',function(){
		//alert($(this).find('.video_src').attr('src'));
		//alert($('.videopreview').attr('src'));
		//$('.videopreview').attr("src", 'http://localhost/notipi/uploads/0f3b4f7d_sample_video.mp4');
		$("#videopreview").html('<source src="'+$(this).find('.video_src').attr('src')+'" ></source>' );
		
			$('#videomodal').modal('show');   
	});
	

});



function add_asset()
{
    save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#modal_form').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Asset'); // Set Title to Bootstrap modal title

}
function add_text_message()
{
    save_method = 'add';
    $('#form_text')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#modal_form_text').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Text'); // Set Title to Bootstrap modal title

}

function edit_asset_text(asset_id)
{
    save_method = 'update';
    $('#form_text')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string


    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('AssetController/ajax_edit')?>/" + asset_id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            $('[name="id"]').val(data.assets_id);
            $('[name="title"]').val(data.filename);
            $('[name="text_message"]').val(data.text_message);

            $('#modal_form_text').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Asset'); // Set title to Bootstrap modal title


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function edit_asset(asset_id)
{
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string


    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('AssetController/ajax_edit')?>/" + asset_id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.asset_id);
            $('[name="name"]').val(data.name);
    
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Asset'); // Set title to Bootstrap modal title


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}

function save_text()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;

    if(save_method == 'add') {
        url = "<?php echo site_url('AssetController/ajax_add_text')?>";
    } else {
        url = "<?php echo site_url('AssetController/ajax_update_text')?>";
    }

    // ajax adding data to database
    var formData = new FormData($('#form_text')[0]);
    $.ajax({
        url : url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $('#modal_form_text').modal('hide');
                reload_table();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
				}
            }
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data'+jqXHR.responseText);
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}

function delete_asset(asset_id)
{
    if(confirm('Are you sure to delete this asset?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('AssetController/ajax_delete')?>/"+asset_id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

    }
}

function bulk_delete()
{
    var list_id = [];
    $(".data-check:checked").each(function() {
            list_id.push(this.value);
    });
    if(list_id.length > 0)
    {
        if(confirm('Are you sure to delete this '+list_id.length+' asset?'))
        {
            $.ajax({
                type: "POST",
                data: {id:list_id},
                url: "<?php echo site_url('AssetController/ajax_bulk_delete')?>",
                dataType: "JSON",
                success: function(data)
                {
                    if(data.status)
                    {
                        reload_table();
                    }
                    else
                    {
                        alert('Failed.');
                    }
                    
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    alert('Error deleting data');
                }
            });
        }
    }
    else
    {
        alert('no data selected');
    }
}

</script>
	
	
    <!-- File Upload -->
    <script>
        $(document).ready(function () {

            $("#multfilesid").fileinput({
				'theme': 'explorer',
				'showRemove': false, // hide remove button
                'allowedFileExtensions': ['jpg', 'png', 'gif', 'mp4', 'ogg', 'webm'],
				'maxFileSize':3000,				
                //'allowedFileExtensions': ['jpg', 'png', 'gif'],
                'uploadAsync': false,
				'uploadUrl': "<?php echo base_url() ?>index.php/Upload/fileinput_upload"

            });

        });
		

    </script>	
	
	
	
	<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" onclick="reload_table();" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Upload Asset</h3>
            </div>
            <div class="modal-body form">
                 <div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"><i class="fa fa-list-alt fa-fw"></i></a>Upload File
						</h4>
					</div>
					<div id="collapseOne" class="panel-collapse collapse in">
						<div class="panel-body">
							<form enctype="multipart/form-data" id="form" class="form-horizontal">
								<input id="multfilesid" name="fileuploads[]" type="file" multiple>
								<br>
							</form>
						</div>
					</div>
				</div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
	



<!-- Bootstrap modal TEXT -->
<div class="modal fade" id="modal_form_text" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Add Text Form</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form_text" class="form-horizontal">
                    <input type="hidden" value="" name="id"/> 
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Title</label>
                            <div class="col-md-9">
                                <input name="title" placeholder="Title" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
                        </div>
						<div class="form-group">
							<label class="control-label col-md-3">Message</label>
                            <div class="col-md-9">
                                <textarea name="text_message" class="form-control" rows="8"></textarea>
                                <span class="help-block"></span>
                            </div>							
						</div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="save_text();" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
	
	
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <img src="" class="imagepreview" style="width: 100%;" >
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
		<video id="videopreview" width="100%" controls muted >
			<source src="" type="video/mp4">
			Your browser does not support the video tag.
		</video>
      </div>
    </div>
  </div>
</div>

</body>

</html>
