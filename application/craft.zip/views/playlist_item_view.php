<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Noti-PI</title>

	<script src="<?php echo base_url('bootstrap/jQuey/jquery-3.2.1.min.js');?>" type="text/javascript"></script>

	
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

	
    <!-- DataTables CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.css');?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.css');?>" rel="stylesheet">

	
    <link href="<?php echo base_url('bootstrap/datatables/css/dataTables.bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('bootstrap/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
	

	<link type="text/css" href="<?php echo base_url('bootstrap/datepicker/css/bootstrap-timepicker.min.css')?>" />
	<script type="text/javascript" src="<?php echo base_url('bootstrap/datepicker/js/bootstrap-timepicker.min.js')?>"></script>


	<style>
	.modal {
	  overflow-y:auto;
	}
	</style>
</head>

<body>

    <div id="wrapper">

        <?php include 'navigation.php'; ?>

	<!-- Page Content -->
	<div id="page-wrapper">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12">		
					
					
					<br/>
					<div class="alert alert-info">
						<b>NOTE:</b> You can now add or edit item/s for your playlist <?php echo $parent_playlist->name?>.
					</div>
					<b><a href="<?php echo base_url() ?>index.php/Playlist/index">
					<i class="fa fa-arrow-left fa-fw" title="Go back to playlist"></i>Go back to playlist</a>
					</b>
					<br/>
					
					
					<div class="panel panel-default">
						<div class="panel-heading ">
							
							<h3 class="text-info">									
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
								<i class="fa fa-list-alt fa-fw"></i></a>
								<?php echo $parent_playlist->name; ?>
							
							</h3>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in">
							<div class="panel-body">
								<button class="btn btn-success" title="Add Playlist Item" onclick="add_playlist_item();"><i class="glyphicon glyphicon-plus"></i> Add Playlist Item</button>
								<button class="btn btn-default" onclick="reload_table()"><i class="glyphicon glyphicon-refresh"></i> Reload</button>
									
								<?php if($this->session->userdata('loggedInParticipant')['super_user'] ){ ?>
								<button class="btn btn-danger" onclick="bulk_delete()"><i class="glyphicon glyphicon-trash"></i>Delete</button>
								<?php }?>
								<br />
								<br />
								
								<table id="table" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th style="width:5%;"><input type="checkbox" id="check-all"></th>
											<th style="width:20%;">Playlist Name</th>
											<!--<th style="width:10%;">Schedule</th>-->
											<th style="width:10%;">Template</th>
											<th style="width:30%;">Assets</th>
											<th style="width:20%;">Created By</th>		
											<th style="width:3%;">Status</th>											
											<th style="width:12%;">Action</th>
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
								
							</div>
						</div>
					</div>						
						
						
						
						
						
						
						
						
					
					
					
					
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!-- jQuery -->
<!-- <script src="../vendor/jquery/jquery.min.js"></script>-->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>



<!-- DataTables JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/datatables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.js');?>"></script>



<script src="<?php echo base_url('bootstrap/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
	
	
	
	
<script type="text/javascript">

var save_method; //for save method string
var table;
var base_url = '<?php echo base_url();?>';

$(document).ready(function() {
	
    //datatables
    table = $('#table').DataTable({
        "responsive": true,
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.

        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('Playlist_item/ajax_list/').$parent_playlist->playlist_id?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
            {
                "targets": [ 0 ], //first column
                "orderable": false, //set not orderable
            },
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },

        ],

    });


    //datepicker
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,  
    });

    //set input/textarea/select event when change value, remove class error and remove text help block 
    $("input").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("textarea").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("select").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });


    //check all
    $("#check-all").click(function () {
        $(".data-check").prop('checked', $(this).prop('checked'));
    });
	
	$('input[name="template"]').change( function() {
	   processAssetSectionToShow(this.value);
	});
	

		
	$(document).on('click','#pop_image',function(){
		$('.imagepreview').attr('src', $(this).find('img').attr('src'));
		$('#imagemodal').modal('show');   
	});
	
	$(document).on('click','#pop_video',function(){
		$("#videopreview").html('<source src="'+$(this).find('.video_src').attr('src')+'" ></source>' );
		$('#videomodal').modal('show');   
	});
	
});

function trigger_click_collapse(type){
	if(type == 1){
		$("#primary_collapse_id").trigger("click");
	}else if(type == 2){
		$("#secondary_collapse_id").trigger("click");
	}else if(type == 3){
		$("#tertiary_collapse_id").trigger("click");
	}else if(type == 4){
		$("#template_collapse_id").trigger("click");
		
	}

}

function edit_asset_text(asset_id)
{
    $('#form_text')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string


    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('AssetController/ajax_edit')?>/" + asset_id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            $('[name="id"]').val(data.assets_id);
            $('[name="title"]').val(data.filename);
            $('[name="text_message"]').val(data.text_message);

            $('#modal_form_text').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('View Text Message'); // Set title to Bootstrap modal title


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function processAssetSectionToShow(value){
	if (value == '1'){
			$('#primary_asset_section').fadeIn('slow');
			$('#secondary_asset_section').fadeOut('slow');
			$('#tertiary_asset_section').fadeOut('slow');

		}
		if (value == '2'){
			$('#primary_asset_section').fadeIn('slow');
			$('#secondary_asset_section').fadeIn('slow');
			$('#tertiary_asset_section').fadeOut('slow');
		}
		if (value == '3'){
			$('#primary_asset_section').fadeIn('slow');
			$('#secondary_asset_section').fadeIn('slow');
			$('#tertiary_asset_section').fadeIn('slow');
		}
}

function add_playlist_item()
{
    save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#modal_form').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Playlist Item'); // Set Title to Bootstrap modal title

	
	$('#primary_asset_section').fadeOut('slow');
	$('#secondary_asset_section').fadeOut('slow');
	$('#tertiary_asset_section').fadeOut('slow');
		
}


function edit_playlist_item(playlist_item_id)
{
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string


    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('Playlist_item/ajax_edit')?>/" + playlist_item_id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.playlist_item_id);
			$('[name="playlist_id"]').val(data.playlist_id);

            $('[name="name"]').val(data.name);
            //$('[name="duration"]').val(data.duration_id);
            //moved to playlist $('[name="start_time"]').val(data.start_time);
			//moved to playlist $('[name="end_time"]').val(data.end_time);
            //$('[name="template"]').val(data.template_id);
			$('input[name="template"][value='+data.template_id+']').prop("checked",true);
            //$('[name="primary_asset"]').val(data.primary_asset_id);
			$('input[name="primary_asset"][value='+data.primary_asset_id+']').prop("checked",true);			
            //$('[name="secondary_asset"]').val(data.secondary_asset_id);
			$('input[name="secondary_asset"][value='+data.secondary_asset_id+']').prop("checked",true);
            //$('[name="tertiary_asset"]').val(data.tertiary_asset_id);
			$('input[name="tertiary_asset"][value='+data.tertiary_asset_id+']').prop("checked",true);
			//moved to playlist $('[name="ticker_message"]').val(data.ticker_message);
			$('[name="year_level"]').val(data.year_level);
			$('[name="start_date"]').val(data.start_date);
			$('[name="end_date"]').val(data.end_date);
			
			
			processAssetSectionToShow(data.template_id);
						
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit '+data.name); // Set title to Bootstrap modal title


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}

function save()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;

    if(save_method == 'add') {
        url = "<?php echo site_url('Playlist_item/ajax_add')?>";
    } else {
        url = "<?php echo site_url('Playlist_item/ajax_update')?>";
    }

    // ajax adding data to database
    var formData = new FormData($('#form')[0]);
    $.ajax({
        url : url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
				
                $('#modal_form').modal('hide');
                reload_table();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update dataaaa'+errorThrown+jqXHR.responseText);
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}

function delete_playlist_item(playlist_item_id)
{
    if(confirm('Are you sure to delete this playlist_item?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('Playlist_item/ajax_delete')?>/"+playlist_item_id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

    }
}

function bulk_delete()
{
    var list_id = [];
    $(".data-check:checked").each(function() {
            list_id.push(this.value);
    });
    if(list_id.length > 0)
    {
        if(confirm('Are you sure to delete this '+list_id.length+' playlist_item?'))
        {
            $.ajax({
                type: "POST",
                data: {id:list_id},
                url: "<?php echo site_url('Playlist_item/ajax_bulk_delete')?>",
                dataType: "JSON",
                success: function(data)
                {
                    if(data.status)
                    {
                        reload_table();
                    }
                    else
                    {
                        alert('Failed.');
                    }
                    
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    alert('Error deleting data');
                }
            });
        }
    }
    else
    {
        alert('no data selected');
    }
}

function approve_pending_playlist_item(playlist_item_id)
{
    if(confirm('Do you want to change the status of this item?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('Playlist_item/approve_pending_playlist_item')?>/"+playlist_item_id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
				 alert( jqXHR.responseText);


            }
        });

    }
}
</script>
	
	
							 
<script type="text/javascript">
	$('#timepicker1').timepicker();
	  var time = $('#timepicker').timepicker('showWidget');

	      // tooltip demo
    $('.tooltip-demo').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })
	  
	$("[data-toggle=popover]")
	.popover()
</script>
	
	
	
	<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog" style="overflow: auto !important;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Playlist Item Form</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
                    <input type="hidden" value="" name="id"/> 
                    <input type="hidden" value="<?php echo $parent_playlist->playlist_id;?>" name="playlist_id"/> 

                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Item Name:</label>
                            <div class="col-md-9">
                                <input name="name" placeholder="Item Name" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
                        </div>
						<div class="form-group">
							<label class="control-label col-md-3">Target Year Level:</label>
                            <div class="col-md-9">                           
								<select name="year_level" class="form-control" style="width:50%">
									<option value="" label="All" selected></option>
									<?php
									foreach($year_level_look_up as $year_level)
									{
										?>
										<option value="<?php echo $year_level->look_up_id?>"><?php echo $year_level->description?></option>
										<?php
									}
									?>
								</select>
                                <span class="help-block"></span>								
							</div>							
						</div>	
						
						<div class="form-group">
                            <label class="control-label col-md-3"> From:</label>
                            <div class="col-md-9">
								<input name="start_date" class="form-control" style="width:50%" type="date"/>
                                <span class="help-block"></span>
                            </div>
						</div>	
						
						<div class="form-group">
                            <label class="control-label col-md-3"> Thru:</label>
                            <div class="col-md-9">
								<input name="end_date" class="form-control" style="width:50%" type="date"/>
                                <span class="help-block"></span>
                            </div>
						</div>	
                        <!--<div class="form-group">
                            <label class="control-label col-md-3">Duration:</label>
                            <div class="col-md-9">
                                <select name="duration" class="form-control">
                                    <option value=""</option>
									<?php
									//foreach($duration_look_up as $duration)
									//{
										?>
										<option value="<?php //echo $duration->look_up_id?>"><?php //echo $duration->description?></option>
										<?php
									//}
									?>
                                </select>
                                <span class="help-block"></span>
                            </div>
						</div>	
						-->
						
						<!--
						<div class="form-group">
                            <label class="control-label col-md-3">Start Time:</label>
                            <div class="col-md-9">
								<input name="start_time" class="form-control" type="time"/>
                                <span class="help-block"></span>
                            </div>
						</div>	
						
						<div class="form-group">
                            <label class="control-label col-md-3">End Time:</label>
                            <div class="col-md-9">
								<input name="end_time" class="form-control" type="time"/>
                                <span class="help-block"></span>
                            </div>
						</div>	
						-->
						
						<div class="form-group">
                            <label class="control-label col-md-3">Template:</label>
                            <div class="col-md-9">
								<div class="panel ">
									<div class="panel-heading ">
									<a id="template_collapse_id" data-toggle="collapse" data-parent="#accordion" href="#collapseTemplate" >
									<i class="fa fa-navicon fa-fw"></i>Choose Template</a>							

									</div>
									<div id="collapseTemplate" class="panel-collapse collapse ">
										<div class="panel-body" >
											<div class="form-group" style="min-height: 400px; max-height: 400px; overflow-y: scroll;">
												<?php
												foreach($template_look_up as $template)
												{
												?>
												<label class="radio-inline" >
													<input onclick="trigger_click_collapse(4);" type="radio" name="template" id="template_id" value="<?php echo $template->look_up_id?>" >
													<?php echo $template->name?>
													<img src="<?php echo base_url().'assets/'.$template->file_name; ?>" class="img-thumbnail" alt="No image" style="height: 150px; width: 100%; display: block;"/>
													
												</label>
												<?php
												}
												?>	
											</div>
										</div>
									</div>
								</div>	
						   
                                <span class="help-block"></span>
                            </div>
						</div>	
						
						<div id="primary_asset_section" class="form-group">
                            <label class="control-label col-md-3">Primary Asset:</label>
                            <div class="col-md-9">
								<div class="panel ">
									<div class="panel-heading ">
									<a id="primary_collapse_id" data-toggle="collapse" data-parent="#accordion" href="#collapsePrimaryAsset" >
									<i class="fa fa-navicon fa-fw"></i>Choose Primary Asset</a>							

									</div>
									<div id="collapsePrimaryAsset" class="panel-collapse collapse">
										<div class="panel-body" >
											<div class="form-group" style="min-height: 300px; max-height: 400px; overflow-y: scroll;">
												<?php
												foreach($assets as $asset)
												{
												?>
												<label class="radio-inline">
													<input onclick="trigger_click_collapse(1);" type="radio" name="primary_asset" id="primary_asset_id" value="<?php echo $asset->assets_id?>" >
													<?php echo $asset->filename;
													?>
												</label>
												<?php if($asset->file_type == 'text'){?>
														<a href="#" onclick="edit_asset_text(<?php echo $asset->assets_id; ?>)">
															<img src="<?php echo base_url().'assets/text.png' ;?>" class="img-thumbnail" alt="No Uploaded File" style="height: 40px; width: 25%; display: block;"/>
														</a>
													<?php
													}else if('mp4' == pathinfo($asset->local_filename, PATHINFO_EXTENSION) ){
													?>
														<a id="pop_video" href="#" class="pop">
															<video width="100px" height="60%"  muted style="height: 40px; width: 25%; display: block;">
																<source class="video_src" src="<?php echo $asset->download_path; ?>">
																Your browser does not support the video tag.
															</video>
														</a>
													<?php
													}else{
													?>
														<a id="pop_image" href="#" class="pop">
															<img src="<?php echo $asset->download_path; ?>" class="img-thumbnail" alt="No image" style="height: 40px; width: 25%; display: block;"/>
														</a>
													<?php
													}
													?>
												<?php
												}?>
											</div>
										</div>
									</div>
								</div>	
                                <span class="help-block"></span>
                            </div>
						</div>
						
						<div id="secondary_asset_section" class="form-group">
                            <label class="control-label col-md-3">Secondary Asset:</label>
                            <div class="col-md-9">
                                <div class="panel ">
									<div class="panel-heading ">
									<a id="secondary_collapse_id" data-toggle="collapse" data-parent="#accordion" href="#collapseSecondaryAsset" >
									<i class="fa fa-navicon fa-fw"></i>Choose Secondary Asset</a>							

									</div>
									<div id="collapseSecondaryAsset" class="panel-collapse collapse">
										<div class="panel-body" >
											<div class="form-group" style="min-height: 300px; max-height: 400px; overflow-y: scroll;">
												<?php
												foreach($assets as $asset)
												{
												?>
												<label class="radio-inline">
													<input onclick="trigger_click_collapse(2);" type="radio" name="secondary_asset" id="secondary_asset_id" value="<?php echo $asset->assets_id?>" >
													<?php echo $asset->filename;
													?>
												</label>
												<?php if($asset->file_type == 'text'){?>
														<a href="#" onclick="edit_asset_text(<?php echo $asset->assets_id; ?>)">
															<img src="<?php echo base_url().'assets/text.png' ;?>" class="img-thumbnail" alt="No Uploaded File" style="height: 40px; width: 25%; display: block;"/>
														</a>
													<?php
													}else if('mp4' == pathinfo($asset->local_filename, PATHINFO_EXTENSION) ){
													?>
														<a id="pop_video" href="#" class="pop">
															<video width="100px" height="60%"  muted style="height: 40px; width: 25%; display: block;">
																<source class="video_src" src="<?php echo $asset->download_path; ?>">
																Your browser does not support the video tag.
															</video>
														</a>
													<?php
													}else{
													?>
														<a id="pop_image" href="#" class="pop">
															<img src="<?php echo $asset->download_path; ?>" class="img-thumbnail" alt="No image" style="height: 40px; width: 25%; display: block;"/>
														</a>
													<?php
													}
													?>
												<?php
												}?>
											</div>
										</div>
									</div>
								</div>	
                                <span class="help-block"></span>
                            </div>
						</div>
						
						<div id="tertiary_asset_section" class="form-group">
                            <label class="control-label col-md-3">Tertiary Asset:</label>
                            <div class="col-md-9">
                                <div class="panel ">
									<div class="panel-heading ">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseTertiaryAsset" >
									<i id="tertiary_collapse_id" class="fa fa-navicon fa-fw"></i>Choose Tertiary Asset</a>							

									</div>
									<div id="collapseTertiaryAsset" class="panel-collapse collapse">
										<div class="panel-body" >
											<div class="form-group" style="min-height: 300px; max-height: 400px; overflow-y: scroll;">
												<?php
												foreach($assets as $asset)
												{
												?>
												<label class="radio-inline">
													<input onclick="trigger_click_collapse(3);" type="radio" name="tertiary_asset" id="tertiary_asset_id" value="<?php echo $asset->assets_id?>" >
													<?php echo $asset->filename;
													?>
												</label>
												<?php if($asset->file_type == 'text'){?>
														<a href="#" onclick="edit_asset_text(<?php echo $asset->assets_id; ?>)">
															<img src="<?php echo base_url().'assets/text.png' ;?>" class="img-thumbnail" alt="No Uploaded File" style="height: 40px; width: 25%; display: block;"/>
														</a>
													<?php
													}else if('mp4' == pathinfo($asset->local_filename, PATHINFO_EXTENSION) ){
													?>
														<a id="pop_video" href="#" class="pop">
															<video width="100px" height="60%"  muted style="height: 40px; width: 25%; display: block;">
																<source class="video_src" src="<?php echo $asset->download_path; ?>">
																Your browser does not support the video tag.
															</video>
														</a>
													<?php
													}else{
													?>
														<a id="pop_image" href="#" class="pop">
															<img src="<?php echo $asset->download_path; ?>" class="img-thumbnail" alt="No image" style="height: 40px; width: 25%; display: block;"/>
														</a>
													<?php
													}
													?>
												<?php
												}?>
											</div>
										</div>
									</div>
								</div>	
                                <span class="help-block"></span>
                            </div>
						</div>
						
						<!--<div class="form-group">
							<label class="control-label col-md-3">Ticker Message</label>
                            <div class="col-md-9">
                                <textarea name="ticker_message" class="form-control" rows="3"></textarea>
                                <span class="help-block"></span>
                            </div>							
						</div>-->

						
						<!--
						<div class="form-group">
                            <label class="control-label col-md-3">Asset:</label>
                            <div class="col-md-9">
							<div class="panel panel-default">
								<div class="panel-body">
									<div class="table-responsive">
										<table id="table_asset" class="table table-hover">
											<thead>
												<tr>
													<th>Select
													<th></th>																					
													<th></th>
												</tr>
											</thead>
											<tbody>
											<?php
											//foreach($assets as $asset)
											//{
												?>
												<tr>
													<th><input type="checkbox" name="assets" class="data-check" value="<?php //echo $asset->assets_id; ?>"></th>

													<th><img src="<?php //echo $asset->download_path; ?>" class="img-thumbnail" alt="Cinque Terre" width="75" height="60"/></th>																					
													<th><?php //echo $asset->filename; ?></th>
												</tr>	
												<?php
											//}
											?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
							-->
							
	
						</div>		
					
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
	
	
	
	

<!-- Bootstrap modal TEXT -->
<div class="modal fade" id="modal_form_text" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">View Text Form</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form_text" class="form-horizontal">
                    <input type="hidden" value="" name="id"/> 
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Title</label>
                            <div class="col-md-9">
                                <input name="title" placeholder="Title" class="form-control" disabled type="text">
                                <span class="help-block"></span>
                            </div>
                        </div>
						<div class="form-group">
							<label class="control-label col-md-3">Message</label>
                            <div class="col-md-9">
                                <textarea name="text_message" class="form-control" disabled rows="8"></textarea>
                                <span class="help-block"></span>
                            </div>							
						</div>
                    </div>
                </form>
            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->	
		

<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <img src="" class="imagepreview" style="width: 100%;" >
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
		<video id="videopreview" width="100%" controls muted >
			<source src="" type="video/mp4">
			Your browser does not support the video tag.
		</video>
      </div>
    </div>
  </div>
</div>
</body>

</html>
