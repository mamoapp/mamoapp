<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Building Collection</title>

	<script src="<?php echo base_url('bootstrap/jQuey/jquery-3.2.1.min.js');?>" type="text/javascript"></script>

	
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

	
    <!-- DataTables CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.css');?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.css');?>" rel="stylesheet">

	
    <link href="<?php echo base_url('bootstrap/datatables/css/dataTables.bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('bootstrap/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
	
    
    <!-- File Upload -->
    <!--<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">-->
    <link href="<?php echo base_url('bootstrap/file/css/fileinput.css');?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url('bootstrap/file/themes/explorer/theme.css');?>" media="all" rel="stylesheet" type="text/css"/>


    <script src="<?php echo base_url('bootstrap/file/js/plugins/sortable.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/fileinput.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/locales/fr.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/js/locales/es.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('bootstrap/file/themes/explorer/theme.js');?>" type="text/javascript"></script>
    <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" type="text/javascript"></script>-->

	<style>
	.modal {
	  overflow-y:auto;
	}
	</style>
</head>

<body>



        <!-- Page Content -->

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">				
                        <br/><br/>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title ">
                                    <b>Building Collection</b>
                                </h4>
                            </div>
                            <div class="panel-body">		
                                <div class="panel panel-default">
                                    <div class="panel-body centered">		
                                        <h1 class="text-danger text-center"><i class="fa fa-pencil fa-fw"></i></h1>
                                        <h4 class="text-center"><a onclick="add_item();" class="text-danger">Add new building</a></h4>
                                        <h5 class="text-center text-muted">Add building information and reference images for building recognition</h5>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="table" class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th style="width:100%;"><b>Building List</b></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                        </div>						
						
						
						
						
						
						
						
						
					
					
					
					
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

<!-- jQuery -->
<!-- <script src="../vendor/jquery/jquery.min.js"></script>-->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>



<!-- DataTables JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/datatables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.js');?>"></script>



<script src="<?php echo base_url('bootstrap/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
	
	
	
	
<script type="text/javascript">

var save_method; //for save method string
var building_uuid;
var table;
var base_url = '<?php echo base_url();?>';

$(document).ready(function() {
 //datatables
    table = $('#table').DataTable({ 
        "responsive": true,
        "paging":   false,
        "searching": false,
        "expand":true,
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('CraftAR/ajax_list')?>",
            "type": "POST"
        }
    });
	
	
var list=document.getElementsByClassName('odd')
for(var i=0;i<list.length;i++){
list[i].click()
}
    //datepicker
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,  
    });

    //set input/textarea/select event when change value, remove class error and remove text help block 
    $("input").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("textarea").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("select").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });


    //check all
    $("#check-all").click(function () {
        $(".data-check").prop('checked', $(this).prop('checked'));
    });

});


function add_item()
{
    save_method = 'add';
    $('#form_add')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#modal_form').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add New Building'); // Set Title to Bootstrap modal title

}

function add_image()
{ 			
	//$('.modal-title_image').text('Add reference image for ' + data.name);
    $('#form_image')[0].reset(); // reset form on modals
    $('.form-group_image').removeClass('has-error'); // clear error class
    $('.help-block_image').empty(); // clear error string
	
	$('[name="img_uuid"]').val(building_uuid);
    $('#modal_form_image').modal('show'); // show bootstrap modal
    //$('.modal-title_image').text('Add reference image for ' + building_name); // Set Title to Bootstrap modal title

}

function edit_item(uuid)
{
    save_method = 'update';
    $('#form_update')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string


    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('CraftAR/ajax_edit')?>/" + uuid,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
			building_uuid = data.uuid;
            $('[name="uuid"]').val(data.uuid);
            $('[name="name"]').val(data.name);
            $('[name="ground_floor"]').val(data.ground_floor);
            $('[name="second_floor"]').val(data.second_floor);
            $('[name="third_floor"]').val(data.third_floor);
			$('[name="fourth_floor"]').val(data.fourth_floor);
			
			$('.modal-title_image').text('Add reference image for ' + data.name);
    
            $('#modal_form_update').modal('show'); // show bootstrap modal when complete loaded
            //$('.modal-title').text('Edit Playlist'); // Set title to Bootstrap modal title
			
			table2 = $('#table_image').DataTable({ 
				"responsive": true,
				"paging":   false,
				"searching": false,
				"expand":true,
				// Load data for the table's content from an Ajax source
				"ajax": {
					"url": "<?php echo site_url('CraftAR/ajax_list_image')?>/"+data.uuid,
					"type": "POST"
				}
			});
			
			table2.destroy();

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });

}

function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}

function save()
{
	


    var url;

    if(save_method == 'add') {
        url = "<?php echo site_url('CraftAR/ajax_add')?>";
		$('#btnSave').text('Saving...'); //change button text
		$('#btnSave').attr('disabled',true); //set button disable 

		// ajax adding data to database
		var formData = new FormData($('#form_add')[0]);
		$.ajax({
			url : url,
			type: "POST",
			data: formData,
			contentType: false,
			processData: false,
			dataType: "JSON",
			success: function(data)
			{
				
				if(data.status) //if success close modal and reload ajax table
				{
					$('#modal_form').modal('hide');
					$('.modal-title_image').text('Add reference image for ' + data.building_name);
					building_uuid = data.uuid;
					add_image(data.name);
					
					reload_table();
				}
				else
				{
					for (var i = 0; i < data.inputerror.length; i++) 
					{
						$('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
						$('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
					}
				}
				
				$('#btnSave').text('Save and continue'); //change button text
				$('#btnSave').attr('disabled',false); //set button enable 
		   
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				alert('Error adding / update data'+jqXHR.textResponse);
				$('#btnSave').text('Save and continue'); //change button text
				$('#btnSave').attr('disabled',false); //set button enable 
				
				$('#btnSave2').text('Save'); //change button text
				$('#btnSave2').attr('disabled',false); //set button enable 

			}
		});

    } else {
        url = "<?php echo site_url('CraftAR/ajax_update')?>";
		$('#btnSave2').text('Saving...'); //change button text
		$('#btnSave2').attr('disabled',true); //set button disable 
		
		// ajax adding data to database
		var formData = new FormData($('#form_update')[0]);
		$.ajax({
			url : url,
			type: "POST",
			data: formData,
			contentType: false,
			processData: false,
			dataType: "JSON",
			success: function(data)
			{
				
				if(data.status) //if success close modal and reload ajax table
				{
					$('#modal_form_update').modal('hide');
										
					reload_table();
				}
				else
				{
					for (var i = 0; i < data.inputerror.length; i++) 
					{
						$('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
						$('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
					}
				}
				
				$('#btnSave2').text('Save'); //change button text
				$('#btnSave2').attr('disabled',false); //set button enable 
		   
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				alert('Error adding / update data'+jqXHR.textResponse);
				$('#btnSave2').text('Save'); //change button text
				$('#btnSave2').attr('disabled',false); //set button enable 

			}
		});
    }

}

function delete_item(id)
{
    if(confirm('Are you really want to delete this item?'))
    {
		$('#notification_modal').modal('show');
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('CraftAR/ajax_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
				//alert('delete success');
                //if success reload ajax table
                $('#notification_modal').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            { 
				$('#notification_modal').modal('hide');
                alert('Error deleting data');
            }
        });

    }
}

function push_to_live(playlist_id)
{
    if(confirm('Are you sure to push this play list to live?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('Playlist/push_to_live')?>/"+playlist_id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
				 alert( jqXHR.responseText);


            }
        });

    }
}

function remove_to_live(playlist_id)
{
    if(confirm('WARNING! This is now currently showing in LIVE. Continuing will remove the playlist from live. '))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('Playlist/remove_to_live')?>/"+playlist_id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
				 alert( jqXHR.responseText);


            }
        });

    }
}

function bulk_delete()
{
    var list_id = [];
    $(".data-check:checked").each(function() {
            list_id.push(this.value);
    });
    if(list_id.length > 0)
    {
        if(confirm('Are you sure to delete this '+list_id.length+' playlist?'))
        {
            $.ajax({
                type: "POST",
                data: {id:list_id},
                url: "<?php echo site_url('Playlist/ajax_bulk_delete')?>",
                dataType: "JSON",
                success: function(data)
                {
                    if(data.status)
                    {
                        reload_table();
                    }
                    else
                    {
                        alert('Failed.');
                    }
                    
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    alert('Error deleting data');
                }
            });
        }
    }
    else
    {
        alert('no data selected');
    }
}

</script>
	
	
<!-- File Upload -->
<script>
    $(document).ready(function () {

        $("#multfilesid").fileinput({
            'theme': 'explorer',
			'showRemove': false,
			'uploadLabel': 'Save',
			'browseLabel': 'Browse',
            'allowedFileExtensions': ['jpg', 'png', 'gif'],
			'maxFileCount':3,
            'maxFileSize':3000,				
            //'allowedFileExtensions': ['jpg', 'png', 'gif'],
            'uploadAsync': false,
			'showCaption': false, 
			'dropZoneEnabled': false,
			'buttonLabelClass':false,
			'fileActionSettings': {showUpload:false}

        });

    });
    

</script>		

	
	
<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Add New Building</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form_add" class="form-horizontal">
                    <input type="hidden" value="" name="id"/> 
                    <div class="form-body">
						<div class="panel panel-default">
							<div class="panel-body">
								<h4><b>Building Information</b></h4>
								<hr/>
								<div class="form-group">
									<label class="control-label col-md-3">Building Name</label>
									<div class="col-md-9">
										<input name="name" class="form-control" type="text">
										<span class="help-block"></span>
									</div>
									<br/>
									<label class="col-md-3">Specify Rooms</label>
									<div class="col-md-9">
										<div class="col-md-6">Ground Floor</div>
										<div class="col-md-12">
											 <textarea name="ground_floor" placeholder="Input ground floor rooms here..." style="width: 100%;" rows="3"></textarea>
										</div>
										<div class="col-md-6">2nd Floor</div>
										<div class="col-md-12">
											 <textarea name="second_floor" placeholder="Input second floor rooms here..." style="width: 100%;" rows="3"></textarea>
										</div>
										
										<div class="col-md-6">3rd Floor</div>
										<div class="col-md-12">
											 <textarea name="third_floor" placeholder="Input third floor rooms here..." style="width: 100%;" rows="3"></textarea>
										</div>
										
										<div class="col-md-6">4th Floor</div>
										<div class="col-md-12">


											 <textarea name="fourth_floor" placeholder="Input fourth floor rooms here..." style="width: 100%;" rows="3"></textarea>
										</div>
									</div>
								</div>
							</div>
							<hr/>

							
						</div>	
					</div>
					
                </form>
			</div>
			<div class="modal-footer">
				<button type="button" id="btnSave" onclick="save();" class="btn btn-primary">Save and continue</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
			
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
	
	

	
	<!--EDIT-->
<div class="modal fade" id="modal_form_update" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body form">
                <form action="#" id="form_update" class="form-horizontal">
                    <input type="hidden" value="" name="id"/> 
                    <div class="form-body">
						<div class="panel panel-default">
							<div class="panel-body">
								<h4><b>Building Information</b></h4>
								<hr/>
								<div class="form-group">
									<input type="hidden" value="" name="uuid"/> 

									<label class="control-label col-md-3">Building Name</label>
									<div class="col-md-9">
										<input name="name" class="form-control" type="text">
										<span class="help-block"></span>
									</div>
									<br/>
									<label class="control-label col-md-3">Specify Rooms</label>
									<div class="col-md-9">
										<div class="control-label col-md-3">Ground Floor</div>
										<div class="col-md-9">
											 <textarea name="ground_floor" placeholder="Input ground floor rooms here..." class="form-control" rows="3"></textarea>
											<span class="help-block"></span>
										</div>
										
										<div class="control-label col-md-3">2nd Floor</div>
										<div class="col-md-9">
											 <textarea name="second_floor" placeholder="Input second floor rooms here..." class="form-control" rows="3"></textarea>
											<span class="help-block"></span>
										</div>
										
										<div class="control-label col-md-3">3rd Floor</div>
										<div class="col-md-9">
											 <textarea name="third_floor" placeholder="Input third floor rooms here..." class="form-control" rows="3"></textarea>
											<span class="help-block"></span>
										</div>
										
										<div class="control-label col-md-3">4th Floor</div>
										<div class="col-md-9">

											 <textarea name="fourth_floor" placeholder="Input fourth floor rooms here..." class="form-control" rows="3"></textarea>
											<span class="help-block"></span>
										</div>
									</div>
								</div>
							</div>
							<hr/>

							<div class="panel-body">
								<h4><b>Reference Image/s</b></h4>
								<hr/>
								
								<div class="panel panel-default">
                                    <div class="panel-body centered">		
                                        <h1 class="text-danger text-center"><i class="fa fa-image fa-fw"></i></h1>
                                        <h4 class="text-center"><a onclick="add_image();" class="text-danger" style="overflow-y: scroll;">Add image</a></h4>
                                        <h5 class="text-center text-muted">Add images to facilitate recognition from different view points</h5>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="table_image" class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th style="width:100%;"><b>Reference Image List</b></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
						</div>	
					</div>
					
                </form>
			</div>
			<div class="modal-footer">
				<button type="button" id="btnSave2" onclick="save();" class="btn btn-primary">Save</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
			
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
	
	
	

	<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form_image" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" onclick="reload_table();" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title_image">Add reference image</h3>
            </div>
            <div class="modal-body form">
                <form enctype="multipart/form-data" action="<?php echo site_url('CraftAR/add_image')?>" method="post" id="form_image" class="form-horizontal">
					<input id="multfilesid" name="fileuploads[]" type="file" multiple>
					<br>
					
					<input type="hidden" value="" name="img_uuid"/> 
				</form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
		
	
	
	
		<!-- Bootstrap modal -->
<div class="modal fade" id="notification_modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title_image">Notice</h3>
            </div>
            <div class="modal-body form">
               <p>Please wait. Delete in progress.</p>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
	
	
	
	
	
	
	
	
	

<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
		<video id="videopreview" width="100%" controls muted >
			<source src="" type="video/mp4">
			Your browser does not support the video tag.
		</video>
      </div>
    </div>
  </div>
</div>

</body>

</html>