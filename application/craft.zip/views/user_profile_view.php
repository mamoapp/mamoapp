<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Noti-PI</title>

	<script src="<?php echo base_url('bootstrap/jQuey/jquery-3.2.1.min.js');?>" type="text/javascript"></script>

	
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('bootstrap/dist/css/sb-admin-2.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('bootstrap/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

	
    <!-- DataTables CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.css');?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.css');?>" rel="stylesheet">

	
    <link href="<?php echo base_url('bootstrap/datatables/css/dataTables.bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('bootstrap/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
	
	
</head>

<body>

    <div id="wrapper">

        <?php include 'navigation.php'; ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">				
						<br/>
						<div class="alert alert-info">
							<b>NOTE:</b> Here you can update your profile information.
						</div>		
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title ">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
									<i class="fa fa-user fa-fw"></i></a>User Profile
                                </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in">
                                <div class="panel-body">
 
									<form action="#" id="form" class="form-horizontal">
										<input type="hidden" value="" name="id"/> 
										<div class="form-body">
											<h4><b><i class="fa fa-info-circle fa-fw"></i>Personal Information:</b></h4>
											
											<div class="form-group">
												<label class="control-label col-md-3">First Name</label>
												<div class="col-md-9">
													<input name="first_name" placeholder="First Name" class="form-control" type="text" value="<?php echo $logged_in_participant->first_name; ?>">
													<span class="help-block"></span>
												</div>
											</div>
											<div class="form-group">
												<label class="control-label col-md-3">Last Name</label>
												<div class="col-md-9">
													<input name="last_name" placeholder="Last Name" class="form-control" type="text" value="<?php echo $logged_in_participant->last_name; ?>">
													<span class="help-block"></span>
												</div>
											</div>
											<div class="form-group">
												<label class="control-label col-md-3">Email Address</label>
												<div class="col-md-9">
													<input name="email_address" placeholder="Email Address" class="form-control" type="text" value="<?php echo $logged_in_participant->email_address; ?>">
													<span class="help-block"></span>
												</div>
											</div>
											
											<div class="form-group">
												<label class="control-label col-md-3">Type of User</label>
												<div class="col-md-9">                           
													<select id="usertypeid" name="user_type" class="form-control" style="width:50%">
														<!--<option value="" label="Select Year Level" ></option>-->
														<?php
														foreach($user_type_look_up as $user_type)
														{
															?>
															<option value="<?php echo $user_type->look_up_id?>"
																<?php if($logged_in_participant->user_type_id == $user_type->look_up_id){echo 'selected';}?>
															>
															<?php echo $user_type->description?>
															</option>
															<?php
														}
														?>
													</select>
													<span class="help-block"></span>								
												</div>							
											</div>
											
											<div id="year_level_section"  class="form-group">
												<label class="control-label col-md-3">Year Level</label>
												<div class="col-md-9">                           
													<select name="year_level" class="form-control" style="width:50%">
														<option value="" label="Select Year Level" ></option>
														<?php
														foreach($year_level_look_up as $year_level)
														{
															?>
															<option value="<?php echo $year_level->look_up_id?>"
																<?php if($logged_in_participant->year_level == $year_level->look_up_id){echo 'selected';}?>
															>
															<?php echo $year_level->description?>
															</option>
															<?php
														}
														?>
													</select>
													<span class="help-block"></span>								
												</div>							
											</div>	
											<div id="course_section" class="form-group">
												<label class="control-label col-md-3">Course</label>
												<div class="col-md-9">
													<input name="course" value="<?php echo $logged_in_participant->course; ?>" class="form-control" placeholder="Course" type="text">
													<span class="help-block"></span>
												</div>
											</div>
											
											<br/>
											<h4><b><i class="fa fa-key fa-fw"></i>Change Password:</b></h4>
											<div class="form-group">
												<label class="control-label col-md-3">Current</label>
												<div class="col-md-9">
													<input name="password" placeholder="Current Password" class="form-control" type="password" >
													<span class="help-block"></span>
												</div>
											</div>
											<div class="form-group">
												<label class="control-label col-md-3">New</label>
												<div class="col-md-9">
													<input name="new_password" placeholder="New Password" class="form-control" type="password" >
													<span class="help-block"></span>
												</div>
											</div>
											<div class="form-group">
												<label class="control-label col-md-3">Retype New</label>
												<div class="col-md-9">
													<input name="retype_password" placeholder="Retype New Password" class="form-control" type="password" >
													<span class="help-block"></span>
												</div>
											</div>
										</div>
									</form>
									<button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </div>						
						
						
						
						
						
						
						
						
					
					
					
					
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!-- jQuery -->
<!-- <script src="../vendor/jquery/jquery.min.js"></script>-->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/bootstrap/js/bootstrap.min.js');?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/metisMenu/metisMenu.min.js');?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('bootstrap/dist/js/sb-admin-2.js');?>"></script>



<!-- DataTables JavaScript -->
<script src="<?php echo base_url('bootstrap/vendor/datatables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-plugins/dataTables.bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('bootstrap/vendor/datatables-responsive/dataTables.responsive.js');?>"></script>



<script src="<?php echo base_url('bootstrap/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
	
	
	
	
<script type="text/javascript">

var save_method; //for save method string
var table;
var base_url = '<?php echo base_url();?>';

$(document).ready(function() {
    //set input/textarea/select event when change value, remove class error and remove text help block 
    $("input").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("textarea").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    $("select").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });

	
	if(<?php echo null != $logged_in_participant->user_type_id? $logged_in_participant->user_type_id : '-1';?> == '9'){// Faculty
		$('#year_level_section').hide()
		$('#course_section').hide()
	}
	$('select').on('change', function() {
		if(this.value == '9'){// Faculty
			$('#year_level_section').fadeOut('slow');
			$('#course_section').fadeOut('slow');
		}else{
			$('#year_level_section').fadeIn('slow');
			$('#course_section').fadeIn('slow');
		}
	})
	
});


function save()
{
	if(confirm('Are you sure you want to save the changes made in you profile?'))
	{

		$('#btnSave').text('saving...'); //change button text
		$('#btnSave').attr('disabled',true); //set button disable 
		var url = "<?php echo site_url('User_profile/ajax_update')?>";


		// ajax adding data to database
		var formData = new FormData($('#form')[0]);
		$.ajax({
			url : url,
			type: "POST",
			data: formData,
			contentType: false,
			processData: false,
			dataType: "JSON",
			success: function(data)
			{
				if(data.status) //if success close modal and reload ajax table
				{
					$('#modal_form').modal('hide');
				}
				else
				{
					for (var i = 0; i < data.inputerror.length; i++) 
					{
						$('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
						$('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
					}
				}
				$('#btnSave').text('save'); //change button text
				$('#btnSave').attr('disabled',false); //set button enable 


			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				alert('Error adding / update data'+jqXHR.responseText);
				$('#btnSave').text('save'); //change button text
				$('#btnSave').attr('disabled',false); //set button enable 

			}
		});
	
	}
}





</script>
	
	
	
	

<div class="modal fade" id="videomodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
		<video id="videopreview" width="100%" controls muted >
			<source src="" type="video/mp4">
			Your browser does not support the video tag.
		</video>
      </div>
    </div>
  </div>
</div>
</body>

</html>
