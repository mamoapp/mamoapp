<!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url() ?>index.php/State_Keeper/redirect_dashboard">
					<img src="<?php echo base_url();?>assets/notipi_logo.png" class="img-rounded" alt="logo" width="150" height="35">

				</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
			
			<!--
				<li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-bell fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-comment fa-fw"></i> Playlist Item "Exam Week" will expire after 15 minutes for today.
                                    <span class="pull-right text-muted small">4 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
					</ul>
                </li>
				-->
			
                <!-- /.dropdown -->
                <li class="dropdown" ><!--
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <li><a href="<?php echo base_url() ?>index.php/User_profile/index"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="<?php echo base_url() ?>index.php/State_Keeper/redirect_login"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>-->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
	
						<?php if($this->session->userdata('loggedInParticipant')['admin_user']
								|| $this->session->userdata('loggedInParticipant')['super_user'] ){ ?>

                        <li>
                            <a href="<?php echo base_url() ?>index.php/State_Keeper/redirect_dashboard"><i class="fa fa-bars fa-fw"></i> Dashboard</a>
                        </li>
						<li>
                            <a href="<?php echo base_url() ?>index.php/Unified_Logs/index"><i class="fa  fa-book fa-fw"></i> Logs and Notices</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url() ?>index.php/AssetController/index"><i class="fa fa-camera-retro fa-fw"></i> Media Manager</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url() ?>index.php/Playlist/index"><i class="fa fa-film fa-fw"></i> Playlist</a>
                        </li>    
						<?php }?>
						<!--
						<li>
                            <a href="schedules.html"><i class="fa fa-clock-o fa-fw"></i> Schedules</a>
                        </li>-->
                        <li>
                            <a href="<?php echo base_url() ?>index.php/Watch_live/tv_monitor"><i class="fa fa-laptop fa-fw"></i> Watch Live</a>
                        </li>
						
						<?php if($this->session->userdata('loggedInParticipant')['super_user'] ){ ?>
                        <li>
                            <a href="<?php echo base_url() ?>index.php/General_settings/index"><i class="fa fa-gears fa-fw"></i> General Settings</a>
                        </li>
						<?php }?>
						<li>
                            <a href="<?php echo base_url() ?>index.php/User_profile/index"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
						<li>
                            <a href="<?php echo base_url() ?>index.php/State_Keeper/redirect_login"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
						
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
		
		