<?php
$query_tz = $this->db->query("SET SESSION time_zone = '+8:00';");
$query_info = $this->db->query("SELECT a.playlist_id, b.is_showing, b.template_id, a.ticker_message, b.year_level, 
								curtime() as time_now, DATE(now()) as date_now, f.first_name, f.last_name, b.created_by,
								DATE_FORMAT(a.start_time,'%H:%i:%s') as start_time, DATE_FORMAT(a.end_time,'%H:%i:%s') as end_time,
								c.local_filename as p1_local_filename, c.file_type as p1_file_type, trim(c.text_message) as p1_text_message, c.filename as p1_title, 
								d.local_filename as p2_local_filename, d.file_type as p2_file_type, trim(d.text_message) as p2_text_message, d.filename as p2_title, 
								e.local_filename as p3_local_filename, e.file_type as p3_file_type, trim(e.text_message) as p3_text_message, e.filename as p3_title
								FROM playlist a
								LEFT JOIN playlist_item b ON a.playlist_id = b.playlist_id
								LEFT JOIN assets c ON b.primary_asset_id = c.assets_id
								LEFT JOIN assets d ON b.secondary_asset_id = d.assets_id
								LEFT JOIN assets e ON b.tertiary_asset_id = e.assets_id
								LEFT JOIN participant f ON b.created_by = f.participant_id
								WHERE a.on_live
								AND b.active
								AND (DATE_FORMAT(a.start_time,'%H:%i:%s') <= curtime() and curtime() <= DATE_FORMAT(a.end_time,'%H:%i:%s') )
								AND (b.start_date = 0000-00-00 or (b.start_date <= DATE(now()) and DATE(now()) <= b.end_date));");
$rows = $query_info->result();		

if(!isset($rows) || $rows == null){
?>
	<div id="t1_primary_div" style="height:43vw; margin: auto; display: block;" class="item active col-xs-12 col-md-12 fade-in two" >
		
		<img src="<?php echo base_url(); ?>assets/notipi_logo.png" class="img-fluid" alt="No image" style="max-width: 100%; max-height: 100%; margin: auto; display: block;"/>

	</div>
<?php
}						

//$countIndex = 0;
foreach($rows as $row){
	if($row->is_showing){
?>
<div class="item <?php if($row->is_showing){echo 'active';}?>">
	<div class="row show-grid" style="height:50vw ">

		
		<!-- Templte 1 -->
	<?php if(isset($row)){ 
		$header_color = '';
		if($row->year_level == 4){// 1st year
			$header_color = 'background-color:MediumSeaGreen;';
		}else if($row->year_level == 5){// 2nd year
			$header_color = 'background-color:DodgerBlue;';
		}else if($row->year_level == 6){// 3rd year
			$header_color = 'background-color:Red;';
		}else if($row->year_level == 7){// 4th year
			$header_color = 'background-color:Yellow;';
		}else if($row->year_level == 8){// 5th year
			$header_color = 'background-color:Violet;';
		}
	?>
		<!-- IF TEMPLATE 1-->
		<?php if($row->template_id == 1){?>
			<div id="t1_primary_div" style="height:99%; max-height: 99%; margin: auto; display: block; <?php echo $header_color;?>" class=" col-xs-12 col-md-12 fade-in three" >
				<!-- IF TYPE TEXT -->
				<?php if($row->p1_file_type == 'text'){?>
				<div style="height:99%; max-height: 99%; margin: auto; display: block;" class="col-xs-12 col-md-12 fade-in three" >
					<p style="<?php echo $header_color;?> font-size: 4vw; text-align: left; max-width: 100%; max-height: 15%; margin: auto; display: block;">
						<?php echo $row->p1_title?>
					</p>
					<pre style="white-space:pre-wrap; word-break: break-word; font-size: 2.5vw; text-align: center; max-width: 100%; max-height: 82%; margin: auto; display: block;"><?php echo $row->p1_text_message?></pre>
					<p style="font-size: 1.5vw; text-align: left;position: absolute; bottom: 0; ">
						<b><?php echo 'POSTED BY: '. $row->first_name.' '. $row->last_name?></b>
					</p>
				</div>
				<!-- IF TYPE VIDEO MP4 -->	
				<?php }else if('mp4' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/mp4">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO ogg -->	
				<?php }else if('ogg' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/ogg">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO webm -->	
				<?php }else if('webm' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/webm">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE IMAGE -->	
				<?php }else{ ?>
				<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" class="img-fluid" alt="No image" style="max-width: 100%; max-height: 100%;margin: auto; display: block;"/>		
				<?php }?>
			</div>
		<?php }?>
		
		<!-- IF TEMPLATE 2-->
		<?php if($row->template_id == 2){?>
			<!-- PRIMARY ASSET-->
			<div id="t2_primary_div" style="height:99%; max-height: 99%; margin: auto; display: block; <?php echo $header_color;?>" class=" col-xs-6 col-md-6 fade-in three" >
				<!-- IF TYPE TEXT -->
				<?php if($row->p1_file_type == 'text'){?>
				<div style="height:99%; max-height: 99%; margin: auto; display: block;" class="col-xs-12 col-md-12 fade-in three" >
					<p style="<?php echo $header_color;?> font-size: 2vw; text-align: left; max-width: 100%; max-height: 15%; margin: auto; display: block;">
						<?php echo $row->p1_title?>
					</p>
					<pre style="white-space:pre-wrap; word-break: break-word; font-size: 2vw; text-align: center; max-width: 100%; max-height: 82%; margin: auto; display: block;"><?php echo $row->p1_text_message?></pre>
					<p style="font-size: 1.5vw; text-align: left;position: absolute; bottom: 0; ">
						<b><?php echo 'POSTED BY: '. $row->first_name.' '. $row->last_name?></b>
					</p>
				</div>
				<!-- IF TYPE VIDEO MP4 -->	
				<?php }else if('mp4' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/mp4">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO ogg -->	
				<?php }else if('ogg' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/ogg">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO webm -->	
				<?php }else if('webm' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/webm">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE IMAGE -->	
				<?php }else{ ?>
				<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" class="img-fluid" alt="No image" style="max-width: 100%; max-height: 100%; margin: auto; display: block;"/>
				<?php }?>
			</div>
			<!-- SECONDARY ASSET-->
			<div id="t2_secondary_div" style="height:99%; max-height: 99%; margin: auto; display: block; <?php echo $header_color;?> " class="col-xs-6 col-md-6 fade-in five" >
				<!-- IF TYPE TEXT -->
				<?php if($row->p2_file_type == 'text'){?>
				<div style="height:99%; max-height: 99%; margin: auto; display: block;" class="col-xs-12 col-md-12 fade-in three" >
					<p style="<?php echo $header_color;?> font-size: 2vw; text-align: left; max-width: 100%; max-height: 15%; margin: auto; display: block;">
						<?php echo $row->p2_title?>
					</p>
					<pre style="white-space:pre-wrap; word-break: break-word; font-size: 2vw; text-align: center; max-width: 100%; max-height: 82%; margin: auto; display: block;"><?php echo $row->p2_text_message?></pre>
					<p style="font-size: 1.5vw; text-align: left;position: absolute; bottom: 0; ">
						<b><?php echo 'POSTED BY: '. $row->first_name.' '. $row->last_name?></b>
					</p>
				</div>
				<!-- IF TYPE VIDEO MP4 -->	
				<?php }else if('mp4' == pathinfo($row->p2_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" type="video/mp4">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO ogg -->	
				<?php }else if('ogg' == pathinfo($row->p2_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" type="video/ogg">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO webm -->	
				<?php }else if('webm' == pathinfo($row->p2_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" type="video/webm">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE IMAGE -->	
				<?php }else{ ?>
				<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" class="img-fluid" alt="No image" style="max-width: 100%; max-height: 100%; margin: auto; display: block;"/>
				<?php }?>
			</div>
		<?php }?>
		
		<!-- IF TEMPLATE 3-->
		<?php if($row->template_id == 3){?>
			<!-- PRIMARY ASSET-->
			<div id="t3_primary_div" style="height:99%; max-height: 99%; margin: auto; display: block; <?php echo $header_color;?>" class=" col-xs-7 col-md-7 fade-in three" >
				<!-- IF TYPE TEXT -->
				<?php if($row->p1_file_type == 'text'){?>
				<div style="height:99%; max-height: 99%; margin: auto; display: block;" class="col-xs-12 col-md-12 fade-in three" >
					<p style="<?php echo $header_color;?> font-size: 2.5vw; text-align: left; max-width: 100%; max-height: 15%; margin: auto; display: block;">
						<?php echo $row->p1_title?>
					</p>
					<pre style="white-space:pre-wrap; word-break: break-word; font-size: 2.5vw; text-align: center; max-width: 100%; max-height: 82%; margin: auto; display: block;"><?php echo $row->p1_text_message?></pre>
					<p style="font-size: 1.5vw; text-align: left;position: absolute; bottom: 0; ">
						<b><?php echo 'POSTED BY: '. $row->first_name.' '. $row->last_name?></b>
					</p>
				</div>				
					
				<!-- IF TYPE VIDEO MP4 -->	
				<?php }else if('mp4' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/mp4">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO ogg -->	
				<?php }else if('ogg' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/ogg">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO webm -->	
				<?php }else if('webm' == pathinfo($row->p1_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename; ?>" type="video/webm">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE IMAGE -->	
				<?php }else{ ?>
					<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p1_local_filename?>" class="img-fluid" alt="No image" style="max-width: 100%; max-height: 100%; margin: auto; display: block;"/>
				<?php }?>
			</div>
			<!-- SECONDARY ASSET-->
			<div id="t3_secondary_div" style=" height:50%; max-height: 49.5%; margin: auto; display: block; <?php echo $header_color;?>" class=" col-xs-5 col-md-5 fade-in five" >
				<!-- IF TYPE TEXT -->
				<?php if($row->p2_file_type == 'text'){?>
				<div style="height:99%; max-height: 99%; margin: auto; display: block;" class="col-xs-12 col-md-12 fade-in three" >
					<p style="<?php echo $header_color;?> font-size: 2vw; text-align: left; max-width: 100%; max-height: 15%; margin: auto; display: block;">
						<?php echo $row->p2_title?>
					</p>
					<pre style="white-space:pre-wrap; word-break: break-word; font-size: 1vw; text-align: center; max-width: 100%; max-height: 82%; margin: auto; display: block;"><?php echo $row->p2_text_message?></pre>
					<p style="font-size: 1vw; text-align: left;position: absolute; bottom: 0; ">
						<b><?php echo 'POSTED BY: '. $row->first_name.' '. $row->last_name?></b>
					</p>
				</div>

				<!-- IF TYPE VIDEO MP4 -->	
				<?php }else if('mp4' == pathinfo($row->p2_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" type="video/mp4">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO ogg -->	
				<?php }else if('ogg' == pathinfo($row->p2_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" type="video/ogg">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO webm -->	
				<?php }else if('webm' == pathinfo($row->p2_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename; ?>" type="video/webm">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE IMAGE -->	
				<?php }else{ ?>
					<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p2_local_filename ?>" class="img-fluid" alt="No image" style="max-width: 100%; max-height: 100%;margin: auto; display: block;"/>
				<?php }?>
			</div>
			<!-- TERTIARY ASSET-->
			<div id="t3_tertiary_div" style=" height:50%; max-height: 49.5%; margin: auto; display: block; <?php echo $header_color;?>" class="col-xs-5 col-md-5 fade-in seven" >
				<!-- IF TYPE TEXT -->
				<?php if($row->p3_file_type == 'text'){?>
				<div style="height:99%; max-height: 99%; margin: auto; display: block;" class="col-xs-12 col-md-12 fade-in three" >
					<p style="<?php echo $header_color;?> font-size: 2vw; text-align: left; max-width: 100%; max-height: 15%; margin: auto; display: block;">
						<?php echo $row->p3_title?>
					</p>
					<pre style="white-space:pre-wrap; word-break: break-word; font-size: 1vw; text-align: center; max-width: 100%; max-height: 82%; margin: auto; display: block;"><?php echo $row->p3_text_message?></pre>
					<p style="font-size: 1vw; text-align: left;position: absolute; bottom: 0; ">
						<b><?php echo 'POSTED BY: '. $row->first_name.' '. $row->last_name?></b>
					</p>
				</div>

				<!-- IF TYPE VIDEO MP4 -->	
				<?php }else if('mp4' == pathinfo($row->p3_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p3_local_filename; ?>" type="video/mp4">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO ogg -->	
				<?php }else if('ogg' == pathinfo($row->p3_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p3_local_filename; ?>" type="video/ogg">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE VIDEO webm -->	
				<?php }else if('webm' == pathinfo($row->p3_local_filename, PATHINFO_EXTENSION) ){?>
				<video width="100%" height="100%" autoplay>
					<source src="<?php echo base_url(); ?>uploads/<?php echo $row->p3_local_filename; ?>" type="video/webm">
					Your browser does not support the video tag.
				</video>
				<!-- IF TYPE IMAGE -->	
				<?php }else{ ?>
					<img src="<?php echo base_url(); ?>uploads/<?php echo $row->p3_local_filename ?>" class="img-fluid" alt="No image" style="max-width: 100%; max-height: 100%;margin: auto; display: block;"/>
				<?php }?>
			</div>

		<?php }?>
		

		
	<?php }else{ ?>
		<div id="t1_primary_div" >
			<img src="<?php echo base_url(); ?>assets/notipi_logo.png" class="img-fluid" alt="No image" style="max-width: 100%; max-height: 100%; margin: auto; display: block;"/>
		</div>
	<?php }?>



	</div>			
</div>		



<?php
	} // if showing end
	//$countIndex++;
}?>

