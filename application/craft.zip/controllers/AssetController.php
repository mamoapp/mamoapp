<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AssetController extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();
		$this->load->model('AssetModel','asset_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('asset');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->asset_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $asset) {
			$no++;
			$row = array();
			$row[] = '<input type="checkbox" class="data-check" value="'.$asset->assets_id.'">';
			if($asset->file_type == 'text'){
				
				$row[] = '<a href="#" onclick="edit_asset_text('."'".$asset->assets_id."'".')">
							<img src="'.base_url().'assets/text.png" class="img-thumbnail" alt="No Uploaded File" width="75" height="60"/>
						</a>';
			}else if('mp4' == pathinfo($asset->local_filename, PATHINFO_EXTENSION) ){
				//controlsList="nodownload"
				$row[] = '<a id="pop_video" href="#" class="pop">
							<video width="75" height="60" muted >
								<source class="video_src" src="'.$asset->download_path.'">
								Your browser does not support the video tag.
							</video>
						</a>';
			}
			/*else if('ogg' == pathinfo($asset->local_filename, PATHINFO_EXTENSION) ){
				$row[] = '<video width="75" height="60" controls muted >
							<source src="'.$asset->download_path.'" type="video/ogg">
							Your browser does not support the video tag.
						</video>';
			}else if('webm' == pathinfo($asset->local_filename, PATHINFO_EXTENSION) ){
				$row[] = '<video width="75" height="60" controls muted >
							<source src="'.$asset->download_path.'" type="video/webm">
							Your browser does not support the video tag.
						</video>';
			}*/
			else {	
				//$row[] = '<img src="'.$asset->download_path.'" class="img-thumbnail" alt="No Uploaded File" width="75" height="60"/>';
				$row[] = '<a id="pop_image" href="#" class="pop">
							<img src="'.$asset->download_path.'" style="width: 75px; height: 60px;">
						</a>';
			}
			$row[] = $asset->filename;
			$row[] = $asset->file_type;
			$row[] = ($asset->file_size / 1000) != 0?($asset->file_size / 1000).'KB': 'N/A';
			

			$action_str = '';
			//add html for action
			//if($asset->text_message != ''){// if this is a text then let's add ability to edit.
				//$action_str = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_asset_text('."'".$asset->assets_id."'".')"><i class="glyphicon glyphicon-pencil"></i></a>';
			//}
			// only super admin can delete assets
			if($this->session->userdata('loggedInParticipant')['super_user']){
				$action_str = $action_str.' <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Delete" onclick="delete_asset('."'".$asset->assets_id."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
			}
			$row[] = $action_str;
			
			
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->asset_model->count_all(),
						"recordsFiltered" => $this->asset_model->count_filtered(),
						"data" => $data
				);
		//output to json format
		echo json_encode($output);
	}
	
	public function ajax_list_as_look_up()
	{
		$this->load->helper('url');

		$list = $this->asset_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $asset) {
			$no++;
			$row = array();
			$row[] = '<input type="checkbox" class="data-check" value="'.$asset->assets_id.'">';
			$row[] = '<img src="'.$asset->download_path.'" class="img-thumbnail" alt="Cinque Terre" width="75" height="60"/>';
			$row[] = $asset->filename;

			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->asset_model->count_all(),
						"recordsFiltered" => $this->asset_model->count_filtered(),
						"data" => $data
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->asset_model->get_by_id($id);
		//echo error_log(json_encode($data));
		echo json_encode($data);
	}

	public function ajax_add()
	{
		$this->_validate();
		
		$data = array(
				'name' => $this->input->post('name')
			);

		$insert = $this->asset_model->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_add_text()
	{
		$this->_validate();
		
		$data = array(
				'filename' => $this->input->post('title'),
				'text_message' => $this->input->post('text_message'),
				'file_type' => 'text'
			);

		$insert = $this->asset_model->save_text($data);

		//error_log(json_encode(array("status" => TRUE)));
		echo json_encode(array("status" => TRUE));
	}
	
	public function ajax_update_text()
	{
		$this->_validate();
		$data = array(
				'filename' => $this->input->post('title'),
				'text_message' => $this->input->post('text_message')
			);
			
		$this->asset_model->update(array('assets_id' => $this->input->post('id')), $data);
		//error_log(json_encode($data));

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();
		$data = array(
				'name' => $this->input->post('name')
			);
		$this->asset_model->update(array('asset_id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		$this->asset_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_bulk_delete()
	{
		$list_id = $this->input->post('id');
		foreach ($list_id as $id) {
			$this->asset_model->delete_by_id($id);
		}
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('title') == '')
		{
			$data['inputerror'][] = 'title';
			$data['error_string'][] = ' Title is required';
			$data['status'] = FALSE;
		}

		if($this->input->post('text_message') == '')
		{
			$data['inputerror'][] = 'text_message';
			$data['error_string'][] = ' Message is required';
			$data['status'] = FALSE;
		}

		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}

	
}
