<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Participant extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Participant_model','participant_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('general_settings_view');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->participant_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $participant) {
			$no++;
			$row = array();
			$row[] = $participant->first_name;
			$row[] = $participant->last_name;
			$row[] = $participant->email_address;
			$row[] = $participant->year_level_description;
			$row[] = $participant->course;

			$permission_button = $participant->admin_user ? 'Faculty/Student Leader Permission' : 'Student Permission';
			//add html for action
			if($participant->admin_user){
				$permission_button = $permission_button.'<br/><a class="btn btn-sm btn-info" href="javascript:void(0)" title="Set as Student" onclick="remove_as_admin('."'".$participant->participant_id."'".')"><i class="glyphicon glyphicon-remove-sign"></i>Set as Student</a>';
			}else{
				$permission_button = $permission_button.'<br/><a class="btn btn-sm btn-success" href="javascript:void(0)" title="Set as Faculty/Student Leader" onclick="mark_as_admin('."'".$participant->participant_id."'".')"><i class="glyphicon glyphicon-ok-sign"></i>Set as Faculty/Student Leader</a>';
			}
			
			
			$row[] = $permission_button;
			
			
			$action_column = ' <a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_participant('."'".$participant->participant_id."'".')"><i class="glyphicon glyphicon-pencil"></i></a>'
											.' <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Delete" onclick="ajax_delete('."'".$participant->participant_id."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
			$row[] = $action_column;
			
			$data[] = $row;
		}
		
		//error_log(json_encode($data));

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->participant_model->count_all(),
						"recordsFiltered" => $this->participant_model->count_filtered(),
						"data" => $data,
				);
		 
		//output to json format
		echo json_encode($output);
	}

	public function mark_as_admin($id)
	{
		$data['admin_user'] = TRUE;
		$this->participant_model->update(array('participant_id' => $id), $data);
		
		
		echo json_encode(array("statusa" => TRUE));
		return;
	}
	public function remove_as_admin($id)
	{
		$data['admin_user'] = FALSE;
		$this->participant_model->update(array('participant_id' => $id), $data);
		
		
		echo json_encode(array("statusa" => TRUE));
		return;
	}
	
	public function reset_password($id)
	{
		$data['password'] = '';
		$this->participant_model->update(array('participant_id' => $id), $data);
		
		
		echo json_encode(array("statusa" => TRUE));
		return;
	}
	
	public function ajax_edit($id)
	{
		$data = $this->participant_model->get_by_id($id);
		echo json_encode($data);
	}

	// This method is for creating participan. AKA. Sign up
	public function ajax_add()
	{
		$this->_validate();
		
		$data = array(
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'email_address' => $this->input->post('signup_email'),
				'password' => $this->input->post('signup_password'),
				'year_level' => $this->input->post('year_level'),
				'course' => $this->input->post('course'),
				'user_type_id' => $this->input->post('user_type'),
			);
			
		error_log(json_encode($data));
		$insert = $this->participant_model->save($data);

		echo json_encode(array("status" => TRUE));
	}

	// Only used in general setting. For User profile go to User_profile.php
	public function ajax_update()
	{
		//$this->_validate();
		$data = array(
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'email_address' => $this->input->post('email'),
				'password' => $this->input->post('password'),
				'year_level' => $this->input->post('year_level'),
				'course' => $this->input->post('course'),
				'user_type_id' => $this->input->post('user_type'),

			);
		$this->participant_model->update(array('participant_id' => $this->input->post('id')), $data);
		
		//error_log(json_encode($data).'idddd'.$this->input->post('id'));
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		$this->participant_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_bulk_delete()
	{
		$list_id = $this->input->post('id');
		foreach ($list_id as $id) {
			$this->participant_model->delete_by_id($id);
		}
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		
		if($this->input->post('first_name') == '')
		{
			$data['inputerror'][] = 'first_name';
			$data['error_string'][] = 'First Name is required';
			$data['status'] = FALSE;
		}
		
		if($this->input->post('last_name') == '')
		{
			$data['inputerror'][] = 'last_name';
			$data['error_string'][] = 'Last Name is required';
			$data['status'] = FALSE;
		}	
	
		if($this->input->post('signup_email') == '')
		{
			$data['inputerror'][] = 'signup_email';
			$data['error_string'][] = 'Email is required';
			$data['status'] = FALSE;
		}else{
			if(!filter_var($this->input->post('signup_email'), FILTER_VALIDATE_EMAIL)){
				$data['inputerror'][] = 'signup_email';
				$data['error_string'][] = 'Invalid Email';
				$data['status'] = FALSE;
			}
		}
		
		if($this->input->post('signup_password') == '')
		{
			$data['inputerror'][] = 'signup_password';
			$data['error_string'][] = 'Password is required';
			$data['status'] = FALSE;
		}	
		
		if($this->input->post('signup_confirm_password') != $this->input->post('signup_password'))
		{
			$data['inputerror'][] = 'signup_confirm_password';
			$data['error_string'][] = 'Password do not match.';
			$data['status'] = FALSE;
		}	
		
		/*
		if($this->input->post('year_level') == '')
		{
			$data['inputerror'][] = 'year_level';
			$data['error_string'][] = 'Year Level is required';
			$data['status'] = FALSE;
		}
		
		if($this->input->post('course') == '')
		{
			$data['inputerror'][] = 'course';
			$data['error_string'][] = 'Course is required';
			$data['status'] = FALSE;
		}			
		*/
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}

}
