<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class General_settings extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->model('Look_up_model', 'look_up_model');
		$data[] = array();
		$data = $this->look_up_model->process_look_ups($data);

		$this->load->view('general_settings_view', $data);
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->participant_model->get_datatables();
		$data = array();
		//$data['aaa'] = 'aaa';
		//error_log(json_encode($data));
		$no = $_POST['start'];
		foreach ($list as $participant) {
			$no++;
			$row = array();
			$row[] = $participant->first_name;
			$row[] = $participant->last_name;
			$row[] = $participant->email_address;
			$row[] = $participant->admin_user ? 'Faculty' : 'Student Leader';

			//add html for action
			$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="mark_as_admin('."'".$participant->participant_id."'".')"><i class="glyphicon glyphicon-user"></i></a>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->participant_model->count_all(),
						"recordsFiltered" => $this->participant_model->count_filtered(),
						"data" => $data,
				);
		 
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->playlist_model->get_by_id($id);
		echo json_encode($data);
	}

	public function ajax_add()
	{
		$this->_validate();
		
		$data = array(
				'name' => $this->input->post('name')
			);

		$insert = $this->playlist_model->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();
		$data = array(
				'name' => $this->input->post('name')
			);
		$this->playlist_model->update(array('playlist_id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		$this->playlist_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_bulk_delete()
	{
		$list_id = $this->input->post('id');
		foreach ($list_id as $id) {
			$this->playlist_model->delete_by_id($id);
		}
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('name') == '')
		{
			$data['inputerror'][] = 'name';
			$data['error_string'][] = 'Playlist Name is required';
			$data['status'] = FALSE;
		}

		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}

	
}
