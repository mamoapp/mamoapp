<?php

class Upload extends CI_Controller {

    public function __construct() {
    
        parent::__construct();
        // Load the helpers
        $this->load->helper(array('form', 'url'));
    }

    public function index() {
        
        // Load the form
        $this->load->view('templates/header');
        $this->load->view('upload/upload_form', array('error' => ' ' ));
        $this->load->view('templates/footer');
        
    }
	
	function reArrayFiles($file_post) {

		$file_ary = array();
		$file_count = count($file_post['name']);
		$file_keys = array_keys($file_post);

		for ($i=0; $i<$file_count; $i++) {
			foreach ($file_keys as $key) {
				$file_ary[$i][$key] = $file_post[$key][$i];
			}
		}

		return $file_ary;
	}
	
	public function craft_file_upload(){
		// 'fileuploads' refers to your file input name attribute
		if (empty($_FILES['fileuploads'])) {
			echo json_encode(['error'=>'No files found for upload.']); 
			// or you can throw an exception 
			return; // terminate
		}

		// get the files posted
		$fileuploads = $_FILES['fileuploads'];
		$file_ary = $this->reArrayFiles($fileuploads);

		$output = [];
		foreach ($file_ary as $fileupload) {
			if (is_uploaded_file($fileupload['tmp_name']) && $fileupload['error']==0) {
				$directory = FCPATH .'uploads/';
				$uniqueFileName = substr(md5(uniqid(rand(1,6))), 0, 8) .'_'. $fileupload['name'];
				$target = $directory.$uniqueFileName;
				if (!file_exists($target)) {
					if (move_uploaded_file($fileupload['tmp_name'], $target)) {
						$this->load->model('UploadModel');
						$data = array('filename' => $fileupload['name'],
										'local_filename' => $uniqueFileName,
										'file_type' => $fileupload['type'],
										'file_size' => $fileupload['size'],
										'full_path' => $target,
										'download_path' => base_url().'uploads/'.$uniqueFileName,
										'added_by_participant_id' => $this->session->userdata('loggedInParticipant')['participant_id']
										);
						
						$this->UploadModel->insertAsset($data);
					}else {
						$output = ['error'=>"The file was not uploaded successfully"];
					}
				}else {
					$output = ['error'=>"File already exists. Please upload another file"];
				}
			}else {
				$output = ['error'=>$fileupload['error']];
			}
		}

		// get user id posted
		//$userid = empty($_POST['userid']) ? '' : $_POST['userid'];

		// get user name posted
		//$username = empty($_POST['username']) ? '' : $_POST['username'];
		/*
		                'uploadExtraData':function(){
					return{
						userid:$("userid").val(),
						username:$("username").val()
					};
				}
		*/
		
		// return a json encoded response for plugin to process successfully
		
		echo json_encode($output);
	}
	
	public function fileinput_upload(){
		// 'fileuploads' refers to your file input name attribute
		if (empty($_FILES['fileuploads'])) {
			echo json_encode(['error'=>'No files found for upload.']); 
			// or you can throw an exception 
			return; // terminate
		}

		// get the files posted
		$fileuploads = $_FILES['fileuploads'];
		$file_ary = $this->reArrayFiles($fileuploads);

		$output = [];
		foreach ($file_ary as $fileupload) {
			if (is_uploaded_file($fileupload['tmp_name']) && $fileupload['error']==0) {
				$directory = FCPATH .'uploads/';
				$uniqueFileName = substr(md5(uniqid(rand(1,6))), 0, 8) .'_'. $fileupload['name'];
				$target = $directory.$uniqueFileName;
				if (!file_exists($target)) {
					if (move_uploaded_file($fileupload['tmp_name'], $target)) {
						$this->load->model('UploadModel');
						$data = array('filename' => $fileupload['name'],
										'local_filename' => $uniqueFileName,
										'file_type' => $fileupload['type'],
										'file_size' => $fileupload['size'],
										'full_path' => $target,
										'download_path' => base_url().'uploads/'.$uniqueFileName,
										'added_by_participant_id' => $this->session->userdata('loggedInParticipant')['participant_id']
										);
						
						$this->UploadModel->insertAsset($data);
					}else {
						$output = ['error'=>"The file was not uploaded successfully"];
					}
				}else {
					$output = ['error'=>"File already exists. Please upload another file"];
				}
			}else {
				$output = ['error'=>$fileupload['error']];
			}
		}

		// get user id posted
		//$userid = empty($_POST['userid']) ? '' : $_POST['userid'];

		// get user name posted
		//$username = empty($_POST['username']) ? '' : $_POST['username'];
		/*
		                'uploadExtraData':function(){
					return{
						userid:$("userid").val(),
						username:$("username").val()
					};
				}
		*/
		
		// return a json encoded response for plugin to process successfully
		
		echo json_encode($output);
	}
    
    /**
     * Multiple upload functionality will fallback to CodeIgniters default do_upload() 
     * method so configuration is backwards compatible between do_upload() and the new do_multi_upload() 
     * method provided by Multi File Upload extension.
     *
     */
    public function do_upload(){
    
        // Detect form submission.
        if($this->input->post('submit')){
        
            $path = './uploads/';
            $this->load->library('upload');
            
            /**
             * Refer to https://ellislab.com/codeigniter/user-guide/libraries/file_uploading.html 
             * for full argument documentation.
             *
             */
             
            // Define file rules
            $this->upload->initialize(array(
                "upload_path"       =>  $path,
                "allowed_types"     =>  "gif|jpg|png|mp4|ogg|webm",
                "max_size"          =>  '',
                "max_width"         =>  '',
                "max_height"        =>  ''
            ));
            
            if($this->upload->do_multi_upload("uploadfile")){
                
                $data['upload_data'] = $this->upload->get_multi_upload_data();
                
                echo '<p class = "bg-success">' . count($data['upload_data']) . 'File(s) successfully uploaded.</p>';
                
            } else {    
                // Output the errors
                $errors = array('error' => $this->upload->display_errors('<p class = "bg-danger">', '</p>'));               
            
                foreach($errors as $k => $error){
                    echo $error;
                }
                
            }
            
        } else {
            echo '<p class = "bg-danger">An error occured, please try again later.</p>';
            
        }
        // Exit to avoid further execution
        exit();
    }
}