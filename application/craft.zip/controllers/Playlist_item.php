<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Playlist_item extends CI_Controller {
	

	private $parent_playlist;
	private $logged_in_pt_info;
	public function __construct()
	{
		parent::__construct();
		$parent_id = $this->uri->segment(3);
		$this->load->model('Playlist_model', 'playlist_model');
		$this->parent_playlist = $this->playlist_model->get_by_id($parent_id);

		$this->load->model('Playlist_item_model','model');
		$this->load->model('Participant_model','participant_model');
		
		$this->logged_in_pt_info = $this->participant_model->get_by_id($this->session->userdata('loggedInParticipant')['participant_id']);

	}

	public function index()
	{
		$data['parent_playlist'] =  $this->parent_playlist;
		
		// process look_ups
		$data = $this->process_look_up($data);

		$this->load->helper('url');
		$this->load->view('playlist_item_view', $data);
	}
	
	private function process_look_up($data){
		$this->load->model('Look_up_model', 'look_up_model');
		//$data['duration_look_up'] = $this->look_up_model->get_by_type('duration');
		//$data['template_look_up'] = $this->look_up_model->get_by_type('template');	
		$data = $this->look_up_model->process_look_ups($data);
		
		$this->load->model('AssetModel','assetmodel');
		$data['assets'] = $this->assetmodel->get_all();
		return $data;
	}

	public function ajax_list($parent_id)
	{
		$this->load->helper('url');

		$list = $this->model->get_datatables($parent_id);
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $playlist_item) {
			$no++;
			$row = array();
			$row[] = '<input type="checkbox" class="data-check" value="'.$playlist_item->playlist_item_id.'">';
			$row[] = $playlist_item->name;
			//$row[] = date("g:i a", strtotime($playlist_item->start_time)).' - '.date("g:i a", strtotime($playlist_item->end_time));
			$row[] = $playlist_item->template_name;
			

			
			$asset_display = '';
			//if(1 == $playlist_item->template_id){
				//$row[] = '<img src="'.$playlist_item->primary_asset.'" title="primary image" class="img-thumbnail" alt="No File Available" width="75" height="60"/>';
			
				if($playlist_item->primary_file_type == 'text'){
					$asset_display = $asset_display.'<img src="'.base_url().'assets/text.png" class="img-thumbnail" alt="No Uploaded File" width="75" height="60"/>';
				}else if('mp4' == pathinfo($playlist_item->primary_asset, PATHINFO_EXTENSION) ){
					//controlsList="nodownload"
					$asset_display = $asset_display.'<video width="75" height="60"  muted >
								<source src="'.$playlist_item->primary_asset.'" >
								Your browser does not support the video tag.
							</video>';
				}
				/*else if('ogg' == pathinfo($playlist_item->primary_asset, PATHINFO_EXTENSION) ){
					$asset_display = $asset_display.'<video width="75" height="60" controls muted >
								<source src="'.$playlist_item->primary_asset.'" type="video/ogg">
								Your browser does not support the video tag.
							</video>';
				}else if('webm' == pathinfo($playlist_item->primary_asset, PATHINFO_EXTENSION) ){
					$asset_display = $asset_display.'<video width="75" height="60" controls muted >
								<source src="'.$playlist_item->primary_asset.'" type="video/webm">
								Your browser does not support the video tag.
							</video>';
				}*/
				else {
					$asset_display = $asset_display.'<img src="'.$playlist_item->primary_asset.'" class="img-thumbnail" alt="No Uploaded File" width="75" height="60"/>';
				}
				
			if(2 == $playlist_item->template_id || 3 == $playlist_item->template_id){	
				if($playlist_item->secondary_file_type == 'text'){
					$asset_display = $asset_display.'<img src="'.base_url().'assets/text.png" class="img-thumbnail" alt="No Uploaded File" width="75" height="60"/>';
				}else if('mp4' == pathinfo($playlist_item->secondary_asset, PATHINFO_EXTENSION) ){
					//controlsList="nodownload"
					$asset_display = $asset_display.'<video width="75" height="60"  muted >
								<source src="'.$playlist_item->secondary_asset.'" >
								Your browser does not support the video tag.
							</video>';
				}
				/*else if('ogg' == pathinfo($playlist_item->secondary_asset, PATHINFO_EXTENSION) ){
					$asset_display = $asset_display.'<video width="75" height="60" controls muted >
								<source src="'.$playlist_item->secondary_asset.'" type="video/ogg">
								Your browser does not support the video tag.
							</video>';
				}else if('webm' == pathinfo($playlist_item->secondary_asset, PATHINFO_EXTENSION) ){
					$asset_display = $asset_display.'<video width="75" height="60" controls muted >
								<source src="'.$playlist_item->secondary_asset.'" type="video/webm">
								Your browser does not support the video tag.
							</video>';
				}*/
				else {
					$asset_display = $asset_display.'<img src="'.$playlist_item->secondary_asset.'" class="img-thumbnail" alt="No Uploaded File" width="75" height="60"/>';
				}
			}	
			if(3 == $playlist_item->template_id){			
				if($playlist_item->tertiary_file_type == 'text'){
					$asset_display = $asset_display.'<img src="'.base_url().'assets/text.png" class="img-thumbnail" alt="No Uploaded File" width="75" height="60"/>';
				}else if('mp4' == pathinfo($playlist_item->tertiary_asset, PATHINFO_EXTENSION) ){
					//controlsList="nodownload"
					$asset_display = $asset_display.'<video width="75" height="60"  muted >
								<source src="'.$playlist_item->tertiary_asset.'" >
								Your browser does not support the video tag.
							</video>';
				}
				/*else if('ogg' == pathinfo($playlist_item->tertiary_asset, PATHINFO_EXTENSION) ){
					$asset_display = $asset_display.'<video width="75" height="60" controls muted >
								<source src="'.$playlist_item->tertiary_asset.'" type="video/ogg">
								Your browser does not support the video tag.
							</video>';
				}else if('webm' == pathinfo($playlist_item->tertiary_asset, PATHINFO_EXTENSION) ){
					$asset_display = $asset_display.'<video width="75" height="60" controls muted >
								<source src="'.$playlist_item->tertiary_asset.'" type="video/webm">
								Your browser does not support the video tag.
							</video>';
				}*/
				else {
					$asset_display = $asset_display.'<img src="'.$playlist_item->tertiary_asset.'" class="img-thumbnail" alt="No Uploaded File" width="75" height="60"/>';
				}
			}	
			$row[] = $asset_display;

			//}else if(2 == $playlist_item->template_id){
			//	$row[] = '<img src="'.$playlist_item->primary_asset.'" title="primary image" class="img-thumbnail" alt="No File Available" width="75" height="60"/>
			///		<img src="'.$playlist_item->secondary_asset.'" title="secondary image" class="img-thumbnail" alt="No File Available" width="75" height="60"/>';				
			//}else if(3 == $playlist_item->template_id){
			//	$row[] = '<img src="'.$playlist_item->primary_asset.'" title="primary image" class="img-thumbnail" alt="No File Available" width="75" height="60"/>
			//		<img src="'.$playlist_item->secondary_asset.'" title="secondary image" class="img-thumbnail" alt="No File Available" width="75" height="60"/>
			//		<img src="'.$playlist_item->tertiary_asset.'" title="tertiary image" class="img-thumbnail" alt="No File Available" width="75" height="60"/>';
			//}
			
			$row[] = $playlist_item->first_name.' '.$playlist_item->last_name;
			
			if($this->session->userdata('loggedInParticipant')['super_user']){
				$row[] = $playlist_item->active?'<button type="button" class="btn btn-sm btn-success btn-xs" onclick="approve_pending_playlist_item('."'".$playlist_item->playlist_item_id."'".')">Active</button>':'<button type="button" class="btn btn-sm btn-danger btn-xs" onclick="approve_pending_playlist_item('."'".$playlist_item->playlist_item_id."'".')">Pending</button>';
			}else{
				$row[] = $playlist_item->active?'<button type="button" class="btn btn-sm btn-success btn-xs">Active</button>':'<button type="button" class="btn btn-sm btn-danger btn-xs" >Pending</button>';

			}
			if($this->session->userdata('loggedInParticipant')['participant_id'] == $playlist_item->created_by
				|| $this->session->userdata('loggedInParticipant')['super_user']){
				//add html for action
				$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_playlist_item('."'".$playlist_item->playlist_item_id."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
					  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Delete" onclick="delete_playlist_item('."'".$playlist_item->playlist_item_id."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
			}else{
				$row[] = 'Not Authorized';
			}

			$data[] = $row;
		}
		$output = array(

						"draw" => $_POST['draw'],
						"recordsTotal" => $this->model->count_all_by_parent($parent_id),
						"recordsFiltered" => $this->model->count_filtered($parent_id),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->model->get_by_id($id);
		echo json_encode($data);
	}

	public function ajax_add()
	{
		$this->_validate();
		
		$dt = new DateTime(); // date today
		$dt->setTimezone(new DateTimezone('+8:00'));

		$data = array(
				'name' => $this->input->post('name'),
				'playlist_id' => $this->input->post('playlist_id'),
				//'duration_id' => $this->input->post('duration'),
				//'start_time' => $this->input->post('start_time'),
				//'end_time' => $this->input->post('end_time'),
				'template_id' => $this->input->post('template'),
				'primary_asset_id' => $this->input->post('primary_asset'),
				'secondary_asset_id' => $this->input->post('secondary_asset'),
				'tertiary_asset_id' => $this->input->post('tertiary_asset'),
				'created_by' => $this->session->userdata('loggedInParticipant')['participant_id'],		
				'log_date_created' => $dt->format('Y-m-d H:i:s'),
				'year_level' => $this->input->post('year_level').'',
				'start_date' => $this->input->post('start_date').'',
				'end_date' => $this->input->post('end_date'),
				//'ticker_message' => $this->input->post('ticker_message'),

				);

		$insert = $this->model->save($data);
		
		// let's update all temp_unique_id's of playlist
		$sql = "UPDATE playlist SET temp_unique_id = '".substr(md5(uniqid(rand(1,9))), 0, 10)."' ;" ;
		$this->db->query($sql);
		
		
		$str_action_log = $this->logged_in_pt_info->first_name.' '.$this->logged_in_pt_info->last_name.' added a new playlist item '.$data['name'].' and is pending for approval by admin.';
		// trigger log
		$logs_sql = "INSERT INTO unified_logs(participant_id, log_date, action, entity_name)
					values (".intval($this->session->userdata('loggedInParticipant')['participant_id']).",
							'". $dt->format('Y-m-d H:i:s') ."',
							'".$str_action_log."',
							'". $data['name'] ."');" ;
		$this->db->query($logs_sql);

		
		
		//error_log(json_encode($data).'aaaaaaaaaaa');
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();
		
		$dt = new DateTime();
		$dt->setTimezone(new DateTimezone('+8:00'));
		
		$data = array(
				'name' => $this->input->post('name'),
				'playlist_id' => $this->input->post('playlist_id'),
				//'duration_id' => $this->input->post('duration'),
				//'start_time' => $this->input->post('start_time'),
				//'end_time' => $this->input->post('end_time'),
				'template_id' => $this->input->post('template'),
				'primary_asset_id' => $this->input->post('primary_asset'),
				'secondary_asset_id' => $this->input->post('secondary_asset'),
				'tertiary_asset_id' => $this->input->post('tertiary_asset'),
				'year_level' => $this->input->post('year_level').'',
				'start_date' => $this->input->post('start_date').'',
				'end_date' => $this->input->post('end_date'),			
				//'ticker_message' => $this->input->post('ticker_message'),
			);
		$this->model->update(array('playlist_item_id' => $this->input->post('id')), $data);
		
		// let's update all temp_unique_id's of playlist
		$sql = "UPDATE playlist SET temp_unique_id = '".substr(md5(uniqid(rand(1,9))), 0, 10)."' ;" ;
		$this->db->query($sql);
		
		
		$str_action_log = $this->logged_in_pt_info->first_name.' '.$this->logged_in_pt_info->last_name.' updated playlist item '.$data['name'];		
		// trigger log
		$logs_sql = "INSERT INTO unified_logs(participant_id, log_date, action, entity_name)
					values (".intval($this->session->userdata('loggedInParticipant')['participant_id']).",
							'".$dt->format('Y-m-d H:i:s')."',
							'".$str_action_log."',
							'". $data['name'] ."');" ;
		$this->db->query($logs_sql);
		
		
		error_log(json_encode($data).'aaaaaaaaaaa');

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{	
		$dt = new DateTime();
		$dt->setTimezone(new DateTimezone('+8:00'));
		
		$data_to_delete = $this->model->get_by_id($id);

		$this->model->delete_by_id($id);
		
		$str_action_log = $this->logged_in_pt_info->first_name.' '.$this->logged_in_pt_info->last_name.' deleted playlist item '.$data_to_delete->name;		
		// trigger log
		$logs_sql = "INSERT INTO unified_logs(participant_id, log_date, action, entity_name)
					values (".intval($this->session->userdata('loggedInParticipant')['participant_id']).",
							'".$dt->format('Y-m-d H:i:s')."',
							'".$str_action_log."',
							'". $data_to_delete->name ."');" ;
		$this->db->query($logs_sql);
		
		
		
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_bulk_delete()
	{
		$list_id = $this->input->post('id');
		foreach ($list_id as $id) {
			
			$dt = new DateTime();
			$dt->setTimezone(new DateTimezone('+8:00'));
			
			$data_to_delete = $this->model->get_by_id($id);
			
			$this->model->delete_by_id($id);
			
			$str_action_log = $this->logged_in_pt_info->first_name.' '.$this->logged_in_pt_info->last_name.' deleted playlist item '.$data_to_delete->name;				
			// trigger log
			$logs_sql = "INSERT INTO unified_logs(participant_id, log_date, action, entity_name)
						values (".intval($this->session->userdata('loggedInParticipant')['participant_id']).",
								'".$dt->format('Y-m-d H:i:s')."',
								'".$str_action_log."',
								'". $data_to_delete->name ."');" ;
			$this->db->query($logs_sql);
			
		}
		echo json_encode(array("status" => TRUE));
	}
	
	public function approve_pending_playlist_item($id)
	{
		
		$this->model->approve_pending_playlist_item($id); 
		
		$dt = new DateTime();
		$dt->setTimezone(new DateTimezone('+8:00'));
		$str_action_log = 'Playlist item '.$this->model->get_by_id($id)->name.' has now changed status by admin.';
		// trigger log
		$logs_sql = "INSERT INTO unified_logs(participant_id, log_date, action, entity_name)
					values (".intval($this->session->userdata('loggedInParticipant')['participant_id']).",
							'". $dt->format('Y-m-d H:i:s') ."',
							'".$str_action_log."',
							'". $this->model->get_by_id($id)->name ."');" ;
		$this->db->query($logs_sql);
		
		
		echo json_encode(array("statusaaa" => TRUE));
		return;
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('name') == '')
		{
			$data['inputerror'][] = 'name';
			$data['error_string'][] = 'Playlist Name is required';
			$data['status'] = FALSE;
		}
		
		if($this->input->post('template') == '')
		{
			$data['inputerror'][] = 'template';
			$data['error_string'][] = 'Tempalte is required';
			$data['status'] = FALSE;
		}
		
		if($this->input->post('template') == '')
		{
			$data['inputerror'][] = 'template';
			$data['error_string'][] = 'Tempalte is required';
			$data['status'] = FALSE;
		}
		
		$proceed_date_compare = true;
		if($this->input->post('start_date') == '' && $this->input->post('end_date') != '')
		{
			$data['inputerror'][] = 'start_date';
			$data['error_string'][] = 'Cannot have from date without thru date.';
			$data['status'] = FALSE;
			
			$proceed_date_compare = false;
		}
		
		if($this->input->post('start_date') != '' && $this->input->post('end_date') == '')
		{
			$data['inputerror'][] = 'end_date';
			$data['error_string'][] = 'Cannot have thru date without from date.';
			$data['status'] = FALSE;
			
			$proceed_date_compare = false;
		}
		
		$start_date = strtotime($this->input->post('start_date').'');
		$end_date =strtotime($this->input->post('end_date').'');
		if($proceed_date_compare && ($start_date > $end_date))
		{
			$data['inputerror'][] = 'end_date';
			$data['error_string'][] = 'Thru Date cannot be less than the From Date.';
			$data['status'] = FALSE;
		}
		
		
		
		
		
		
		/*
		$start_time = $this->input->post('start_time');
		$end_time = $this->input->post('end_time');
		if($start_time == '' || $end_time ==''){
			if($start_time == ''){
				$data['inputerror'][] = 'start_time';
				$data['error_string'][] = 'Start Time is required.';
				$data['status'] = FALSE;
			}
			if($end_time == ''){
				$data['inputerror'][] = 'end_time';
				$data['error_string'][] = 'End Time is required.';
				$data['status'] = FALSE;
			}
		}else if($start_time == $end_time){
			$data['inputerror'][] = 'start_time';
			$data['error_string'][] = 'Start and End time should not be same.';
			$data['status'] = FALSE;
			
			$data['inputerror'][] = 'end_time';
			$data['error_string'][] = 'Start and End time should not be same.';
			$data['status'] = FALSE;
		}else{
			$queryStr = "SELECT DATE_FORMAT(start_time, '%H:%i') as start_time, DATE_FORMAT(end_time, '%H:%i') as end_time 
									FROM playlist_item 
									WHERE playlist_id = ".$this->input->post('playlist_id');
			
			if(null != $this->input->post('id')){
				$queryStr = $queryStr." AND NOT playlist_item_id = ".$this->input->post('id') ;
			}
			
			
			$query = $this->db->query($queryStr);

									
			foreach ($query->result() as $row)
			{			
			$arr['poststart'] = $this->input->post('start_time');
			$arr['rowend'] = $row->end_time;
			$arr['boolval'] = ($this->input->post('start_time') < $row->end_time);

				if( ($row->start_time <  $this->input->post('end_time'))
					&& ($this->input->post('start_time') < $row->end_time) ){
					$data['inputerror'][] = 'start_time';
					$data['error_string'][] = 'Specified duration is occupied. Please select another time duration.';
					$data['status'] = FALSE;
					
					$data['inputerror'][] = 'end_time';
					$data['error_string'][] = 'Specified duration is occupied. Please select another time duration.';
					$data['status'] = FALSE;

					break;
				}
			}

		}*/
		

		if($data['status'] === FALSE)
		{
			
			echo json_encode($data);
			exit();
		}
	}
	
}
