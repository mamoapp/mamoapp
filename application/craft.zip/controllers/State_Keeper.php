<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class State_Keeper extends CI_Controller {

	public function index()
	{
		$this->redirect_login();
	}
	
	public function redirect_login()
	{
		$data = array();
		$this->load->model('Look_up_model', 'look_up_model');
		$data = $this->look_up_model->process_look_ups($data);
		$this->load->view('login', $data);
	}
	
	public function redirect_dashboard()
	{
		$this->load->view('dashboard');
	}
	
	public function redirect_media_manager()
	{
		$this->load->view('media_manager');
	}
	
	public function redirect_create_playlist()
	{
		$this->load->view('create_playlist');
	}
	
	public function redirect_schedule()
	{
		$this->load->view('schedule');
	}
	
	public function redirect_date_time()
	{
		$this->load->view('dashboard_side_menu/date_time');
	}
	
	public function redirect_monitor()
	{
		$this->load->view('dashboard_side_menu/monitor');
	}
	
	public function redirect_mcb_building()
	{
		$this->load->view('buildings/mcb_building');
	}
	
	public function redirect_it_building()
	{
		$this->load->view('buildings/it_building');
	}
	
	public function redirect_si_building()
	{
		$this->load->view('buildings/si_building');
	}
	
	
	
		
	
	
}
