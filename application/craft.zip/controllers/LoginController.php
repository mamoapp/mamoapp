<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('LoginModel','loginmodel');
	}

	public function index()
	{
		$this->redirect_login();
	}
	
	public function redirect_login()
	{
		redirect(base_url().'index.php/State_Keeper/redirect_login');
	}
	
	public function processLogin()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		
		if($this->loginmodel->canLogin($email, $password)){
			
			//$session_data = array(
			//	'email' => $email
			//	);
			//$this->session->set_userdata($session_data);
			$this->enter($email);
		}else{
			
			$this->session->set_flashdata('error', 'Invalid Email or Password');
			$this->redirect_login();
		}
	}
	
	public function loginValidation(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email', 'Email', 'required');
		//$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run()){
			$this->processLogin();
		}else{
			$this->redirect_login();
		}
	}

	public function enter($email){
		//$session_data = $this->session->userdata();
		//$session_data['email']
		$singleResult = $this->loginmodel->fetchParticipantByEmail($email);
		foreach($singleResult as $participant){
			$loggedInParticipant = array(
									'participant_id' => $participant->participant_id,
									'first_name' => $participant->first_name,
									'last_name' => $participant->last_name,
									'email_address' => $participant->email_address,
									'password' => $participant->password,
									'admin_user' => $participant->admin_user,
									'super_user' => $participant->super_user,
									);
			break;
		}

		$this->session->set_userdata('loggedInParticipant', $loggedInParticipant);
		

		
		if($loggedInParticipant['first_name'] != ''){
			redirect(base_url().'index.php/State_Keeper/redirect_dashboard');
			
		}else{
			$this->redirect_login();
		}
	}
	
	
	public function signupValidation(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('firstName', 'FirstName', 'required');
		$this->form_validation->set_rules('lastName', 'LastName', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run()){
			$this->processSignup();
		}else{
			$this->redirect_login();
		}
	}
	
	public function processSignup()
	{
		$firstName = $this->input->post('firstName');
		$lastName = $this->input->post('lastName');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		
		if($this->loginmodel->canCreateNewParticipant($email)){
			
			$data = array('first_name' => $firstName,
						'last_name' => $lastName,
						'email_address' => $email,
						'password' => $password);
						
			$signupSuccess = $this->loginmodel->insertParticipant($data);
			if($signupSuccess){
				$this->session->set_flashdata('signupSuccess', 'Your account has been created.');
			}else{
				$this->session->set_flashdata('signupSuccess', 'Sorry! Unexpected Error while saving.');
			}
			$this->redirect_login();
		}else{
			
			$this->session->set_flashdata('email_already_exists', 'Email Address Already Exist!');
			$this->redirect_login();
		}
		
		
	}
	
}
