<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_profile extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Participant_model','participant_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$data['logged_in_participant'] = $this->participant_model->get_by_id($this->session->userdata('loggedInParticipant')['participant_id']);
		$this->load->model('Look_up_model', 'look_up_model');
		$data = $this->look_up_model->process_look_ups($data);

		$this->load->view('user_profile_view', $data);
	}
	
	public function ajax_update()
	{
		$this->_validate();
		$data = array(
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'email_address' => $this->input->post('email_address'),
				'year_level' => $this->input->post('year_level'),
				'course' => $this->input->post('course'),
				'user_type_id' => $this->input->post('user_type'),

			);
		
		// It's now safe to update because this was already went to validation
		if($this->input->post('new_password') != null){
			$data['password'] = $this->input->post('new_password');
			$this->session->userdata('loggedInParticipant')['password'] = $this->input->post('new_password');		
			$loggedInParticipant = array(
				'participant_id' => $this->session->userdata('loggedInParticipant')['participant_id'],
				'first_name' => $this->session->userdata('loggedInParticipant')['first_name'],
				'last_name' => $this->session->userdata('loggedInParticipant')['last_name'],
				'email_address' => $this->session->userdata('loggedInParticipant')['email_address'],
				'admin_user' => $this->session->userdata('loggedInParticipant')['admin_user'],
				'super_user' => $this->session->userdata('loggedInParticipant')['super_user'],
				//update password in the loggedInParticipant session variable
				'password' => $this->input->post('new_password')
				);
		$this->session->set_userdata('loggedInParticipant', $loggedInParticipant);

		}	
			
		$this->participant_model->update(array('participant_id' => $this->session->userdata('loggedInParticipant')['participant_id']), $data);
		
		error_log(json_encode($data));
		
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('first_name') == '')
		{
			$data['inputerror'][] = 'first_name';
			$data['error_string'][] = 'First Name is required';
			$data['status'] = FALSE;
		}
		
		if($this->input->post('last_name') == '')
		{
			$data['inputerror'][] = 'last_name';
			$data['error_string'][] = 'Last Name is required';
			$data['status'] = FALSE;
		}
		
		if($this->input->post('email_address') == '')
		{
			$data['inputerror'][] = 'email_address';
			$data['error_string'][] = 'Email Address is required';
			$data['status'] = FALSE;
		}
		
		if($this->input->post('year_level') == '')
		{
			$data['inputerror'][] = 'year_level';
			$data['error_string'][] = 'Year Level is required';
			$data['status'] = FALSE;
		}

		if($this->input->post('course') == '')
		{
			$data['inputerror'][] = 'course';
			$data['error_string'][] = 'Course is required';
			$data['status'] = FALSE;
		}
		
		$current_password = $this->input->post('password');
		$new_password = $this->input->post('new_password');
		$retype_password = $this->input->post('retype_password');
		if(null != $new_password || null != $retype_password || null != $current_password){
			if($current_password != $this->session->userdata('loggedInParticipant')['password']){
				$data['inputerror'][] = 'password';
				$data['error_string'][] = 'Your Password was incorrect!';
				$data['status'] = FALSE;
			}
			
			if($new_password == ''){
				$data['inputerror'][] = 'new_password';
				$data['error_string'][] = 'New password should not be blank!';
				$data['status'] = FALSE;
			}
			
			if($new_password != $retype_password){
				$data['inputerror'][] = 'retype_password';
				$data['error_string'][] = 'New password did not match!';
				$data['status'] = FALSE;
			}
		}
		

		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}

}
