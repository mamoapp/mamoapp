<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CraftAR extends CI_Controller {
	
    var $apiKey = "8c50ccb8a93ae6cd2da78e826fe9e08e6151e077";
    var $collectionUUID = "01c36ea606594fa0a276b9695af4cd56";

	public function __construct()
	{
		parent::__construct();
		$this->load->model('CraftAR_model','craftar_model');
	}

	public function index()
	{
		$this->load->helper('url');
		
		$this->load->model('Look_up_model', 'look_up_model');
		$data = array();
		$data = $this->look_up_model->process_look_ups($data);

		$this->load->view('craft_item_view', $data);
	}

	public function ajax_list()
	{
		$this->load->helper('url');
		$data = array();
        
        $list = $this->craftar_model->get_items();
        $count = $this->craftar_model->count_all();
        for($i=0; $i < $count; $i++){
            $item = $list[$i];
			$row = array();
            
            $str = "<b>".$item->name."</b>";
            $str = $str."<hr>";
            $str = $str."<b>UUID: </b>".$item->uuid;
            $str = $str."<br/>";
            $str = $str."<br/>";
            $str = $str.'<a class="btn btn-xs btn-outline btn-danger" style="margin-right: 4px;" href="javascript:void(0)" title="Delete" onclick="delete_item('."'". $item->uuid."'".')">Delete</a>';
            $str = $str.'<a class="btn btn-xs btn-info" href="javascript:void(0)" title="View Item" onclick="edit_item('."'". $item->uuid."'".')">View Item</a>';
            $row[] = $str;
			
			$data[] = $row;
		}

		$output = array(
						"draw" =>0,
						"recordsTotal" => $count,
						"recordsFiltered" => $count,
						"data" => $data
				);
		//output to json format
		
		echo json_encode($output);
	}
	
	public function ajax_list_image($uuid)
	{
		$this->load->helper('url');
		$data = array();
        
        $list = $this->craftar_model->get_images($uuid);
        $count = $this->craftar_model->count_all_images($uuid);
        for($i=0; $i < $count; $i++){
            $item = $list[$i];
			$row = array();
			
			$str ="<div style='text-align: center;'>		";
			$str = $str."<br/><img src='$item->thumb_120' width='100%' height='100%' style='display: block; margin:auto;'></img>";
			$str = $str."<br/><b>UUID:</b>".$item->uuid;
			$str = $str."<br/><b>Status:</b>".$item->status;
			$str = $str."<br/><b>Quality:</b>".($item->quality*100)."%";
			$str = $str."</div>";
            
            $row[] = $str;
			
			$data[] = $row;
		}

		$output = array(
						"draw" =>0,
						"recordsTotal" => $count,
						"recordsFiltered" => $count,
						"data" => $data
				);
		//output to json format
		
		echo json_encode($output);
	}


	public function ajax_edit($id)
	{
		$data = $this->craftar_model->get_item($id);
		echo json_encode($data);
	}

	// make sure to update temp_unique_id every time a playlist is inserted/updated
	public function ajax_add()
	{

		$this->_validate();
		$data = array(
				'name' => $this->input->post('name'),
				'ground_floor' => $this->input->post('ground_floor'),
				'second_floor' => $this->input->post('second_floor'),
				'third_floor' => $this->input->post('third_floor'),
				'fourth_floor' => $this->input->post('fourth_floor')
		);
		
		// Create an empty item in your collection:
		$name = $data['name']; // use your own item name
		$url = "http://catchoom.com"; // and your own url
		$custom = ""; // and your own custom data
		$optionalData = array("url" => $url, "custom" => $custom);
		// to create trackable items ( AR Items )
		// $optionalData["tracking"] = "true";

		$response = $this->management->createItem($this->collectionUUID, $name, $optionalData);
		$item = $response->getBody();
		sleep(2);
		$data['uuid'] = $item->uuid;
		
		
		$insert = $this->craftar_model->save($data);
		echo json_encode(array("status" => TRUE, "building_name" => $data['name'], "uuid" => $data['uuid'] ));
	}

	function reArrayFiles($file_post) {

		$file_ary = array();
		$file_count = count($file_post['name']);
		$file_keys = array_keys($file_post);

		for ($i=0; $i<$file_count; $i++) {
			foreach ($file_keys as $key) {
				$file_ary[$i][$key] = $file_post[$key][$i];
			}
		}

		return $file_ary;
	}
	
	public function add_image()
	{
		if (empty($_FILES['fileuploads'])) {
			echo json_encode(['error'=>'No files found for upload.']); 
			// or you can throw an exception 
			return; // terminate
		}

		// get the files posted
		$fileuploads = $_FILES['fileuploads'];
		$file_ary = $this->reArrayFiles($fileuploads);

		$output = [];
		foreach ($file_ary as $fileupload) {
			if (is_uploaded_file($fileupload['tmp_name']) && $fileupload['error']==0) {
				$data = array(
					'tmp_img' => $fileupload['tmp_name'],
					'uuid' => $this->input->post('img_uuid'));
				
				//error_log('BBBBBB'.json_encode($data));
				$this->craftar_model->save_image($data);
						
			}else {
				$output = ['error'=>$fileupload['error']];
			}
		}
		
		header("Location:".site_url('CraftAR/')); /* Redirect browser */
		exit();


	}
	
	public function ajax_update()
	{
		$this->_validate();
		$data = array(
				'name' => $this->input->post('name'),
				'ground_floor' => $this->input->post('ground_floor'),
				'second_floor' => $this->input->post('second_floor'),
				'third_floor' => $this->input->post('third_floor'),
				'fourth_floor' => $this->input->post('fourth_floor')
		);
		
		$this->craftar_model->update(array('uuid' => $this->input->post('uuid')), $data);
		error_log('BBBBBB'.json_encode($data).$this->input->post('uuid'));
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		$this->craftar_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
	
	public function push_to_live($id)
	{
		
		$this->craftar_model->push_to_live_playlist($id); // now let's update the selected playlist to be on_live
		
		echo json_encode(array("statusaaa" => TRUE));
		return;
	}
	
	public function remove_to_live($id)
	{
		$this->craftar_model->remove_to_live_playlist($id); // now let's update the selected playlist to be on_live
		
		echo json_encode(array("statusaa" => TRUE));
		return;
	}

	public function ajax_bulk_delete()
	{
		$list_id = $this->input->post('id');
		foreach ($list_id as $id) {
			$this->craftar_model->delete_by_id($id);
		}
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('name') == '')
		{
			$data['inputerror'][] = 'name';
			$data['error_string'][] = 'Building Name is required';
			$data['status'] = FALSE;
		}
		
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
	
}
