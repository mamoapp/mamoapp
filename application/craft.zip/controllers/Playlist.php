<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Playlist extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Playlist_model','playlist_model');
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('playlist_view');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->playlist_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $playlist) {
			$no++;
			$row = array();
			
			$row[] = '<input type="checkbox" class="data-check" value="'.$playlist->playlist_id.'">';			
			$row[] = '<b><a href="'.base_url().'index.php/playlist_item/index/'.$playlist->playlist_id.'"><i class="fa fa-mail-forward fa-fw"></i>'.$playlist->name.'</a></b>';
			$row[] = date("g:i a", strtotime($playlist->start_time)).' - '.date("g:i a", strtotime($playlist->end_time));
			$row[] = $playlist->on_live? '<b><p class="text-warning"><i class="fa fa-check"></i>Active on live</p></b>' : '';
			//add html for action
			if($playlist->on_live){
				$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_playlist('."'".$playlist->playlist_id."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Delete" onclick="delete_playlist('."'".$playlist->playlist_id."'".')"><i class="glyphicon glyphicon-trash"></i></a>
				  <a class="btn btn-sm btn-warning" href="javascript:void(0)" title="Remove to live" onclick="remove_to_live('."'".$playlist->playlist_id."'".')"><i class="glyphicon glyphicon-off"></i>Remove to live</a>';
			}else{
				$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_playlist('."'".$playlist->playlist_id."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
					  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Delete" onclick="delete_playlist('."'".$playlist->playlist_id."'".')"><i class="glyphicon glyphicon-trash"></i></a>
					  <a class="btn btn-sm btn-info" href="javascript:void(0)" title="Push to live" onclick="push_to_live('."'".$playlist->playlist_id."'".')"><i class="glyphicon glyphicon-upload"></i>Push to live</a>';				
			}
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->playlist_model->count_all(),
						"recordsFiltered" => $this->playlist_model->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->playlist_model->get_by_id($id);
		echo json_encode($data);
	}

	// make sure to update temp_unique_id every time a playlist is inserted/updated
	public function ajax_add()
	{
		$this->_validate();
		$dt = new DateTime();
		$data = array(
				'name' => $this->input->post('name'),
				'start_time' => $this->input->post('start_time'),
				'end_time' => $this->input->post('end_time'),
				'ticker_message' => $this->input->post('ticker_message'),
				'temp_unique_id' => substr(md5(uniqid(rand(1,9))), 0, 10),
				'created_by' => $this->session->userdata('loggedInParticipant')['participant_id'],				
				'log_date_created' => $dt->format('Y-m-d H:i:s'),
			);

		$insert = $this->playlist_model->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();
		$data = array(
				'name' => $this->input->post('name'),
				'start_time' => $this->input->post('start_time'),
				'end_time' => $this->input->post('end_time'),
				'ticker_message' => $this->input->post('ticker_message'),
				'temp_unique_id' => substr(md5(uniqid(rand(1,9))), 0, 10)
			);
		$this->playlist_model->update(array('playlist_id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		$this->playlist_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
	
	public function push_to_live($id)
	{
		
		$this->playlist_model->push_to_live_playlist($id); // now let's update the selected playlist to be on_live
		
		echo json_encode(array("statusaaa" => TRUE));
		return;
	}
	
	public function remove_to_live($id)
	{
		$this->playlist_model->remove_to_live_playlist($id); // now let's update the selected playlist to be on_live
		
		echo json_encode(array("statusaa" => TRUE));
		return;
	}

	public function ajax_bulk_delete()
	{
		$list_id = $this->input->post('id');
		foreach ($list_id as $id) {
			$this->playlist_model->delete_by_id($id);
		}
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('name') == '')
		{
			$data['inputerror'][] = 'name';
			$data['error_string'][] = 'Playlist Name is required';
			$data['status'] = FALSE;
		}
		
		$start_time = $this->input->post('start_time');
		$end_time = $this->input->post('end_time');
		if($start_time == '' || $end_time ==''){
			if($start_time == ''){
				$data['inputerror'][] = 'start_time';
				$data['error_string'][] = 'Start Time is required.';
				$data['status'] = FALSE;
			}
			if($end_time == ''){
				$data['inputerror'][] = 'end_time';
				$data['error_string'][] = 'End Time is required.';
				$data['status'] = FALSE;
			}
		}else if($start_time == $end_time){
			$data['inputerror'][] = 'start_time';
			$data['error_string'][] = 'Start and End time should not be same.';
			$data['status'] = FALSE;
			
			$data['inputerror'][] = 'end_time';
			$data['error_string'][] = 'Start and End time should not be same.';
			$data['status'] = FALSE;
		}else{
			$queryStr = "SELECT DATE_FORMAT(start_time, '%H:%i') as start_time, DATE_FORMAT(end_time, '%H:%i') as end_time 
									FROM playlist WHERE 1 = 1 ";
			if(null != $this->input->post('id')){
				$queryStr = $queryStr." AND NOT playlist_id = ".$this->input->post('id') ;
			}
			
			$query = $this->db->query($queryStr);
									
			foreach ($query->result() as $row)
			{			
				$arr['poststart'] = $this->input->post('start_time');
				$arr['rowend'] = $row->end_time;
				$arr['boolval'] = ($this->input->post('start_time') < $row->end_time);

				if( ($row->start_time <  $this->input->post('end_time'))
					&& ($this->input->post('start_time') < $row->end_time) ){
					$data['inputerror'][] = 'start_time';
					$data['error_string'][] = 'Specified duration is occupied. Please select another time duration.';
					$data['status'] = FALSE;
					
					$data['inputerror'][] = 'end_time';
					$data['error_string'][] = 'Specified duration is occupied. Please select another time duration.';
					$data['status'] = FALSE;

					break;
				}
			}
		}
		
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
	
}
