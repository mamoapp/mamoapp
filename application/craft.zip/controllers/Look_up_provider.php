<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Look_up_provider extends CI_Controller {

	public function index()
	{
		
	}
	
	public function process_look_up($data){
		$this->load->model('Look_up_model', 'look_up_model');
		$data['duration_look_up'] = $this->look_up_model->get_by_type('duration');
		$data['template_look_up'] = $this->look_up_model->get_by_type('template');	
		$data['year_level_look_up'] = $this->look_up_model->get_by_type('YearLevel');
		
		$this->load->model('AssetModel','assetmodel');
		$data['assets'] = $this->assetmodel->get_all();
		return $data;
	}
	
		
	
	
}
