<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Watch_live extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();

		$this->load->model('Watch_live_model','model');
	}

	public function index()
	{		
		$this->load->helper('url');
		$this->load->view('watch_live_view');
	}
	
	public function tv_monitor(){
		$this->load->view('tv_monitor_view');
	}

	public function ajax_live_view(){
		$this->load->view('ajax_live_view');
	}
	
	public function real_date_time(){
		$data = array();
		$query_tz = $this->db->query("SET SESSION time_zone = '+8:00';");
		$query_time = $this->db->query("SELECT DATE_FORMAT(now(), '  %M %d, %Y   ') as date_now, DATE_FORMAT(now(), '%h:%i %p') as time_now");
		$time = $query_time->row();
		$data['date_now'] = $time->date_now;
		$data['time_now'] = $time->time_now;

		//error_log(json_encode($time));
		echo json_encode($data);

	}
	
	public function ajax_live_show(){
		$this->load->model('Playlist_model', 'playlist_model');
		$this->playlist_model->get_by_id(2);
	}
	
	public function ajax_list($parent_id)
	{
		$this->load->helper('url');

		$list = $this->model->get_datatables($parent_id);
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $playlist_item) {
			$no++;
			$row = array();
			$row[] = '<input type="checkbox" class="data-check" value="'.$playlist_item->playlist_item_id.'">';
			$row[] = $playlist_item->name;
			
			//add html for action
			$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_playlist_item('."'".$playlist_item->playlist_item_id."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Delete" onclick="delete_playlist_item('."'".$playlist_item->playlist_item_id."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->model->count_all(),
						"recordsFiltered" => $this->model->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->model->get_by_id($id);
		echo json_encode($data);
	}

	public function ajax_add()
	{
		$this->_validate();
		
		$data = array(
				'name' => $this->input->post('name'),
				'playlist_id' => $this->input->post('playlist_id'),
				'duration_id' => $this->input->post('duration'),
				'template_id' => $this->input->post('template'),
				'primary_asset_id' => $this->input->post('primary_asset'),
				'secondary_asset_id' => $this->input->post('secondary_asset'),
				'tertiary_asset_id' => $this->input->post('tertiary_asset'),

				);

		$insert = $this->model->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();
		$data = array(
				'name' => $this->input->post('name'),
				'playlist_id' => $this->input->post('playlist_id'),
				'duration_id' => $this->input->post('duration'),
				'template_id' => $this->input->post('template'),
				'primary_asset_id' => $this->input->post('primary_asset'),
				'secondary_asset_id' => $this->input->post('secondary_asset'),
				'tertiary_asset_id' => $this->input->post('tertiary_asset'),
			);
		$this->model->update(array('playlist_item_id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		$this->model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_bulk_delete()
	{
		$list_id = $this->input->post('id');
		foreach ($list_id as $id) {
			$this->model->delete_by_id($id);
		}
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('name') == '')
		{
			$data['inputerror'][] = 'name';
			$data['error_string'][] = 'Playlist Name is required';
			$data['status'] = FALSE;
		}

		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}

	
	public function fetch_item_info($counter)
	{
		$data = array();
		$query_tz = $this->db->query("SET SESSION time_zone = '+8:00';");
		$query_info = $this->db->query("SELECT a.playlist_id, a.temp_unique_id, b.playlist_item_id, b.template_id, a.ticker_message,
										curtime() as time_now,
										DATE_FORMAT(a.start_time,'%H:%i:%s') as start_time, DATE_FORMAT(a.end_time,'%H:%i:%s') as end_time,
										c.local_filename as p1_local_filename, c.file_type as p1_file_type, c.text_message as p1_text_message,
										d.local_filename as p2_local_filename, d.file_type as p2_file_type, d.text_message as p2_text_message,
										e.local_filename as p3_local_filename, e.file_type as p3_file_type, e.text_message as p3_text_message
										FROM playlist a
										LEFT JOIN playlist_item b ON a.playlist_id = b.playlist_id
										LEFT JOIN assets c ON b.primary_asset_id = c.assets_id
										LEFT JOIN assets d ON b.secondary_asset_id = d.assets_id
										LEFT JOIN assets e ON b.tertiary_asset_id = e.assets_id
										WHERE a.on_live
										AND b.active
										AND (DATE_FORMAT(a.start_time,'%H:%i:%s') <= curtime() and curtime() <= DATE_FORMAT(a.end_time,'%H:%i:%s') )
										AND (b.start_date = 0000-00-00 or (b.start_date <= DATE(now()) and DATE(now()) <= b.end_date))
										limit 1 offset ". (int)$counter);
		$rows = $query_info->row();	
		
		$query_size = $this->db->query("SELECT count(*) as total_count
										FROM playlist a
										LEFT JOIN playlist_item b ON a.playlist_id = b.playlist_id
										LEFT JOIN assets c ON b.primary_asset_id = c.assets_id
										LEFT JOIN assets d ON b.secondary_asset_id = d.assets_id
										LEFT JOIN assets e ON b.tertiary_asset_id = e.assets_id
										WHERE a.on_live
										AND b.active
										AND (DATE_FORMAT(a.start_time,'%H:%i:%s') <= curtime() and curtime() <= DATE_FORMAT(a.end_time,'%H:%i:%s') )
										AND (b.start_date = 0000-00-00 or (b.start_date <= DATE(now()) and DATE(now()) <= b.end_date));");
		$row_total = $query_size->row();	

		//$unique_id = null != $rows ? $rows->temp_unique_id : '0';

		//$data['temp_unique_id'] = $unique_id;
		
		$sql_update_false = "UPDATE playlist_item SET is_showing = FALSE;";
		$this->db->query($sql_update_false);
		
		if(isset($rows)){
			$sql_update = "UPDATE playlist_item SET is_showing = TRUE WHERE playlist_item_id = ". (int)$rows->playlist_item_id;
			$this->db->query($sql_update);
		}
		
		//$data['counter'] = $counter;
		
		$data['size'] = isset($row_total)? $row_total->total_count: 0;
		
		//error_log(json_encode($data).'ccccccccccccc');
		echo json_encode($data);

	}
	
	
}
