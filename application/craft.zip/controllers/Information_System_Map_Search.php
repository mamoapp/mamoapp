<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Information_System_Map_Search extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();

	}

	public function index()
	{		
		$this->load->helper('url');
		
		$this->load->model('Look_up_model', 'look_up_model');
		$data = array();
		$data = $this->look_up_model->process_look_ups($data);
		$this->load->view('information_system_map_search_view', $data);
				 
	}

	
	
	
}
